# NOVA Voice Assistant - Android Project

NOVA is an offline-first and AI-assisted Android voice assistant designed for seamless voice actions, system control, and automation.

---

## Project Specifications

- **Application ID:** `com.nova.assistant`
- **Compile SDK:** `35` (Android 15)
- **Min SDK:** `26` (Android 8.0 Oreo)
- **Target SDK:** `35` (Android 15)
- **Android Gradle Plugin (AGP):** `8.8.0`
- **Kotlin Version:** `2.0.21` (Kotlin Compose Plugin)
- **Gradle Version:** `8.10.2` (Official verified wrapper included)
- **Java Compatibility:** JDK 17

---

## How to Build the APK From Your Android Phone (₹0 Budget, No PC Needed)

You can build this project using **GitHub Actions**, which provides free cloud build machines equipped with Android SDK 35 and JDK 17.

### Step 1: Create a GitHub Repository on Your Phone
1. Open your browser on your phone (Chrome, Firefox, Samsung Internet) and visit [github.com](https://github.com).
2. Sign in or sign up for a free account.
3. Tap the **+** (New) button in the top menu and select **New repository**.
4. Set the repository name to `nova-android` (Public or Private).
5. Tap **Create repository**.

### Step 2: Upload This Project to GitHub
**Method A (Direct Upload in Mobile Browser - Easiest):**
1. Unzip `nova-android-project-ready.zip` on your phone (using your phone's built-in "Files" app or any file manager).
2. On your new GitHub repository page, tap **"uploading an existing file"**.
3. Select the project files and tap **Commit changes**.
   *(Ensure the `.github/workflows/build-apk.yml` file is included in your repo).*

**Method B (GitHub Desktop Site / Web):**
- In your phone's browser, tap the 3-dots menu and enable **"Desktop site"** for a full desktop interface, which supports drag-and-drop or batch file selection.

### Step 3: Run the Cloud Build
1. In your GitHub repository, tap the **Actions** tab at the top.
2. Under "All workflows", tap **Build Android Debug APK**.
3. Tap the **Run workflow** dropdown button, select branch `main`, and tap the green **Run workflow** button.
4. The build will start. It takes about **2 to 3 minutes** to download Gradle, compile Jetpack Compose, assemble DEX, and produce the APK.

### Step 4: Download and Install on Your Phone
1. Once the workflow run shows a green checkmark (✓), tap on it to view details.
2. Scroll down to the **Artifacts** section at the bottom of the page.
3. Tap **`nova-assistant-debug-apk`**.
4. Your phone will download a ZIP containing `app-debug.apk`.
5. Tap the downloaded file in your notifications or Files app, extract it, and tap **`app-debug.apk`** to install NOVA on your phone!

---

## "Hey NOVA" wake word (offline, Vosk)

- Engine: [Vosk](https://alphacephei.com/vosk/) (`com.alphacephei:vosk-android`), model `vosk-model-small-en-us-0.15` (Apache 2.0).
- The model is **downloaded at build time** by the Gradle task `fetchVoskModel` (needs network once; skipped if
  `app/src/main/assets/model-en-us/` already contains the unzipped model). Optional integrity pin:
  `./gradlew assembleDebug -PvoskModelSha256=<sha256-of-the-zip>` (the build log prints the actual hash).
- At runtime the model is copied to app-private storage and loaded on a background thread; the load fails with a
  clear message if the model's vocabulary lacks "hey"/"nova". If the model is missing, push-to-talk still works.
- Audio: 16 kHz, mono, PCM 16-bit. Detection = Vosk grammar `["hey nova", "[unk]"]`, exact consecutive words only.
- Flow: `WAKE_WORD_LISTENING` (AudioRecord owned by `WakeWordListener`) -> mic released -> "Yes?" -> `COMMAND_LISTENING`
  (SpeechRecognizer) -> command executed -> back to `WAKE_WORD_LISTENING`.
- Tests: `./gradlew testDebugUnitTest` (JVM logic tests) and `./gradlew connectedDebugAndroidTest` (real model + real audio on a device/emulator).
