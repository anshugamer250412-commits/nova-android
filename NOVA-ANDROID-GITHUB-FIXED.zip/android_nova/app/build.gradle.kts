import java.io.File
import java.net.URL
import java.security.MessageDigest
import java.util.zip.ZipInputStream

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
}

// ---------------------------------------------------------------------------------------------
// Offline wake-word model (Vosk) - "Hey NOVA" detection
//
// Model:  vosk-model-small-en-us-0.15 (Apache 2.0, ~40 MB) from https://alphacephei.com/vosk/models
// Why this one: the small Vosk models ship a dynamic graph (HCLr.fst + Gr.fst), which is required
//               for Recognizer(model, rate, grammar) - the restricted-phrase mode used for wake-word
//               spotting. Large "HCLG" server models do NOT support runtime grammars.
// The model is downloaded once at build time into build/generated/voskModel/model-en-us and merged
// into the APK assets. If you prefer to bundle it manually, unzip it to
// app/src/main/assets/model-en-us/ (am/, conf/, graph/, ivector/) and the download is skipped.
// Optional integrity pin: ./gradlew assembleDebug -PvoskModelSha256=<sha256 of the zip>
// ---------------------------------------------------------------------------------------------
abstract class FetchVoskModelTask : DefaultTask() {
    @get:Input
    abstract val modelUrl: Property<String>

    @get:Input
    @get:Optional
    abstract val expectedSha256: Property<String>

    /** Manually bundled model (src/main/assets/model-en-us). When it exists no download happens. */
    @get:Internal
    abstract val manualModelDir: DirectoryProperty

    @get:OutputDirectory
    abstract val outputDir: DirectoryProperty

    @TaskAction
    fun fetch() {
        val manual = manualModelDir.get().asFile
        if (File(manual, "am/final.mdl").exists()) {
            logger.lifecycle("Vosk model found in ${manual.path}; skipping download.")
            return
        }
        val target = File(outputDir.get().asFile, "model-en-us")
        if (File(target, "am/final.mdl").exists()) {
            logger.lifecycle("Vosk model already present in ${target.path}")
            return
        }
        target.deleteRecursively()
        target.mkdirs()

        val zipFile = File(temporaryDir, "vosk-model.zip")
        logger.lifecycle("Downloading Vosk model: ${modelUrl.get()}")
        URL(modelUrl.get()).openStream().use { input ->
            zipFile.outputStream().use { out -> input.copyTo(out) }
        }

        val digest = MessageDigest.getInstance("SHA-256")
        zipFile.inputStream().use { ins ->
            val buf = ByteArray(1 shl 16)
            while (true) {
                val n = ins.read(buf)
                if (n < 0) break
                digest.update(buf, 0, n)
            }
        }
        val actual = digest.digest().joinToString("") { "%02x".format(it) }
        logger.lifecycle("Vosk model zip SHA-256: $actual")
        if (expectedSha256.isPresent && !expectedSha256.get().equals(actual, ignoreCase = true)) {
            throw GradleException("Vosk model SHA-256 mismatch: expected ${expectedSha256.get()} but got $actual")
        }

        // Unzip, dropping the single top-level folder (vosk-model-small-en-us-0.15/).
        val targetCanonical = target.canonicalPath + File.separator
        ZipInputStream(zipFile.inputStream().buffered()).use { zin ->
            while (true) {
                val entry = zin.nextEntry ?: break
                val rel = entry.name.substringAfter('/', "")
                if (rel.isEmpty() || entry.isDirectory) continue
                val outFile = File(target, rel)
                if (!outFile.canonicalPath.startsWith(targetCanonical)) {
                    throw GradleException("Blocked suspicious zip entry: ${entry.name}")
                }
                outFile.parentFile.mkdirs()
                outFile.outputStream().use { zin.copyTo(it) }
            }
        }
        if (!File(target, "am/final.mdl").exists()) {
            throw GradleException("Vosk model download did not produce am/final.mdl - unexpected archive layout")
        }
        logger.lifecycle("Vosk model unpacked to ${target.path}")
    }
}

val fetchVoskModel = tasks.register<FetchVoskModelTask>("fetchVoskModel") {
    group = "nova"
    description = "Downloads the offline Vosk model used for 'Hey NOVA' wake-word detection."
    modelUrl.set("https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip")
    providers.gradleProperty("voskModelSha256").orNull?.let { expectedSha256.set(it) }
    manualModelDir.set(layout.projectDirectory.dir("src/main/assets/model-en-us"))
    outputDir.set(layout.buildDirectory.dir("generated/voskModel"))
}

androidComponents {
    onVariants { variant ->
        variant.sources.assets?.addGeneratedSourceDirectory(fetchVoskModel, FetchVoskModelTask::outputDir)
    }
}

android {
    namespace = "com.nova.assistant"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.nova.assistant"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
    testOptions {
        unitTests {
            isReturnDefaultValues = true
            all {
                it.testLogging {
                    events("passed", "skipped", "failed", "standardOut", "standardError")
                    showExceptions = true
                    showCauses = true
                    showStackTraces = true
                    exceptionFormat = org.gradle.api.tasks.testing.logging.TestExceptionFormat.FULL
                }
            }
        }
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.activity.compose)
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.ui)
    implementation(libs.androidx.ui.graphics)
    implementation(libs.androidx.ui.tooling.preview)
    implementation(libs.androidx.material3)
    implementation(libs.androidx.material.icons.extended)
    implementation(libs.androidx.navigation.compose)
    implementation(libs.kotlinx.coroutines.android)

    // Offline wake-word engine (Vosk). Vosk talks to its native library through JNA, which must be
    // the Android AAR flavour (carries libjnidispatch.so); the plain jar pulled in transitively is excluded.
    implementation(libs.vosk.android) {
        exclude(group = "net.java.dev.jna", module = "jna")
    }
    implementation("net.java.dev.jna:jna:${libs.versions.jna.get()}@aar")

    testImplementation(libs.junit)
    testImplementation(libs.json)

    androidTestImplementation(libs.androidx.junit)

    debugImplementation(libs.androidx.ui.tooling)
    debugImplementation(libs.androidx.ui.test.manifest)
}
