package com.nova.assistant

import android.Manifest
import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.util.Log
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.nova.assistant.wakeword.VoskWakeWordEngine
import com.nova.assistant.wakeword.WakeWordListener
import com.nova.assistant.wakeword.WakeWordModelStore
import com.nova.assistant.wakeword.WakeWordState
import org.junit.AfterClass
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assume.assumeTrue
import org.junit.Before
import org.junit.BeforeClass
import org.junit.Test
import org.junit.runner.RunWith
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Random
import kotlin.math.PI
import kotlin.math.sin

/**
 * On-device tests: they load the REAL Vosk model through the REAL Vosk native library and feed REAL
 * PCM audio through VoskWakeWordEngine. Run with:  ./gradlew connectedDebugAndroidTest
 *
 * Audio fixtures live in androidTest/assets/wake_test/{positive,negative}/ (16 kHz mono PCM16 WAV).
 * The bundled clips are synthetic text-to-speech; add recordings of real people for a stronger check.
 */
@RunWith(AndroidJUnit4::class)
class WakeWordInstrumentedTest {

    companion object {
        private const val TAG = "WakeWordInstrumentedTest"
        private const val RATE = VoskWakeWordEngine.SAMPLE_RATE_HZ
        private const val FRAME = RATE / 10

        private val instrumentation = InstrumentationRegistry.getInstrumentation()
        private val appContext get() = instrumentation.targetContext
        private val testAssets get() = instrumentation.context.assets

        lateinit var engine: VoskWakeWordEngine

        @JvmStatic
        @BeforeClass
        fun loadModelOnce() {
            instrumentation.uiAutomation.grantRuntimePermission(appContext.packageName, Manifest.permission.RECORD_AUDIO)
            engine = VoskWakeWordEngine()
            val result = engine.initialize(appContext)
            Log.i(TAG, "engine.initialize -> $result state=${engine.state} error=${engine.lastError}")
        }

        @JvmStatic
        @AfterClass
        fun releaseModel() {
            engine.release()
        }
    }

    @Before
    fun resetDecoder() {
        engine.resetSession()
    }

    // ---- A. model loading ------------------------------------------------------------------

    @Test
    fun realModelLoadsAndVocabularyContainsWakeWords() {
        assertEquals("model must load: ${engine.lastError}", WakeWordState.READY, engine.state)
        assertTrue(engine.isReady)

        val installed = WakeWordModelStore.install(appContext).getOrThrow()
        assertTrue(WakeWordModelStore.validate(installed).isSuccess)
        Log.i(TAG, "Model installed at ${installed.absolutePath}")
    }

    // ---- B. detection of "Hey Nova" ----------------------------------------------------------

    @Test
    fun detectsHeyNovaClips() {
        val clips = clipNames("positive")
        assumeTrue("no positive clips found", clips.isNotEmpty())
        val failures = clips.filterNot { name ->
            val hit = feed(withSilence(loadWav("positive/$name")))
            Log.i(TAG, "positive $name -> detected=$hit")
            hit
        }
        assertTrue("Wake phrase NOT detected in: $failures", failures.isEmpty())
    }

    // ---- C. no false activation ----------------------------------------------------------------

    @Test
    fun ignoresUnrelatedSpeechClips() {
        val clips = clipNames("negative")
        assumeTrue("no negative clips found", clips.isNotEmpty())
        val falseHits = clips.filter { name ->
            engine.resetSession()
            val hit = feed(withSilence(loadWav("negative/$name")))
            Log.i(TAG, "negative $name -> detected=$hit")
            hit
        }
        assertTrue("False activation on: $falseHits", falseHits.isEmpty())
    }

    @Test
    fun ignoresLoudWhiteNoise() {
        val rnd = Random(42)
        val noise = ShortArray(RATE * 30) { ((rnd.nextGaussian() * 6000).toInt()).coerceIn(-32768, 32767).toShort() }
        assertFalse("white noise must not wake NOVA", feed(noise))
    }

    @Test
    fun ignoresHumAndClicks() {
        val rnd = Random(7)
        val hum = ShortArray(RATE * 30) { i ->
            val tone = 9000 * sin(2 * PI * 120 * i / RATE) + rnd.nextGaussian() * 800
            tone.toInt().coerceIn(-32768, 32767).toShort()
        }
        assertFalse("mains hum must not wake NOVA", feed(hum))

        val clicks = ShortArray(RATE * 30)
        var i = 0
        while (i < clicks.size) {
            for (k in 0 until 80) if (i + k < clicks.size) clicks[i + k] = (if (k % 2 == 0) 28000 else -28000).toShort()
            i += RATE / 2
        }
        assertFalse("clicks must not wake NOVA", feed(clicks))
    }

    @Test
    fun ignoresSilence() {
        assertFalse(feed(ShortArray(RATE * 20)))
    }

    // ---- E. microphone release / transfer -------------------------------------------------------

    @SuppressLint("MissingPermission")
    @Test
    fun listenerReleasesMicrophoneAndCaptureThreadOnStop() {
        val listener = WakeWordListener(engine, onWakeWord = {}, onFailure = { Log.w(TAG, "listener failure: $it") })
        val started = listener.start()
        assertTrue("start must succeed: ${started.exceptionOrNull()}", started.isSuccess)
        Thread.sleep(600)
        assertTrue(listener.isActive)

        listener.stop()
        assertFalse(listener.isActive)
        assertTrue(
            "capture thread must be gone after stop()",
            Thread.getAllStackTraces().keys.none { it.name == "nova-wakeword-capture" && it.isAlive }
        )

        // The microphone must be usable by the next owner (e.g. SpeechRecognizer) right away.
        val next = AudioRecord(
            MediaRecorder.AudioSource.VOICE_RECOGNITION, RATE,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, RATE
        )
        try {
            assertEquals(AudioRecord.STATE_INITIALIZED, next.state)
            next.startRecording()
            assertEquals(AudioRecord.RECORDSTATE_RECORDING, next.recordingState)
        } finally {
            if (next.recordingState == AudioRecord.RECORDSTATE_RECORDING) next.stop()
            next.release()
        }

        // ...and wake-word capture can resume afterwards.
        val resumed = WakeWordListener(engine, onWakeWord = {}, onFailure = {})
        assertTrue(resumed.start().isSuccess)
        resumed.stop()
        assertTrue(Thread.getAllStackTraces().keys.none { it.name == "nova-wakeword-capture" && it.isAlive })
    }

    // ---- helpers ----------------------------------------------------------------------------

    private fun clipNames(dir: String): List<String> =
        (testAssets.list("wake_test/$dir") ?: emptyArray()).filter { it.endsWith(".wav") }.sorted()

    /** Feeds audio in 100 ms frames, exactly like WakeWordListener does. True on first detection. */
    private fun feed(pcm: ShortArray): Boolean {
        var offset = 0
        val frame = ShortArray(FRAME)
        while (offset < pcm.size) {
            val n = minOf(FRAME, pcm.size - offset)
            System.arraycopy(pcm, offset, frame, 0, n)
            if (engine.processAudioFrame(frame, n)) return true
            offset += n
        }
        return false
    }

    private fun withSilence(speech: ShortArray): ShortArray {
        val lead = ShortArray(RATE / 2)
        val tail = ShortArray(RATE * 2)
        return lead + speech + tail
    }

    /** Minimal RIFF/WAVE parser; requires 16 kHz mono PCM16 (the format the engine needs). */
    private fun loadWav(assetPath: String): ShortArray {
        val bytes = testAssets.open("wake_test/$assetPath").use { it.readBytes() }
        val buf = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        require(String(bytes, 0, 4) == "RIFF" && String(bytes, 8, 4) == "WAVE") { "$assetPath is not a WAV file" }
        var pos = 12
        var data: ShortArray? = null
        while (pos + 8 <= bytes.size) {
            val id = String(bytes, pos, 4)
            val size = buf.getInt(pos + 4)
            val body = pos + 8
            if (id == "fmt ") {
                val format = buf.getShort(body).toInt()
                val channels = buf.getShort(body + 2).toInt()
                val rate = buf.getInt(body + 4)
                val bits = buf.getShort(body + 14).toInt()
                require(format == 1 && channels == 1 && rate == RATE && bits == 16) {
                    "$assetPath must be 16 kHz mono PCM16 (got fmt=$format ch=$channels rate=$rate bits=$bits)"
                }
            } else if (id == "data") {
                val count = minOf(size, bytes.size - body) / 2
                data = ShortArray(count) { buf.getShort(body + it * 2) }
                break
            }
            pos = body + size + (size and 1)
        }
        return requireNotNull(data) { "$assetPath has no data chunk" }
    }
}
