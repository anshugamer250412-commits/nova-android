# Wake-word test audio

16 kHz, mono, PCM 16-bit WAV clips used by `WakeWordInstrumentedTest`.

* `positive/` - must trigger "Hey NOVA"
* `negative/` - must NOT trigger

The bundled clips were generated with the flite text-to-speech voices (kal, slt, rms, awb) - they are
**synthetic**. A synthetic voice can fail to match for accent reasons without the engine being wrong, so
add recordings of real people (same format) to both folders for a meaningful result.
Record e.g. with: `ffmpeg -i input.m4a -ar 16000 -ac 1 -c:a pcm_s16le hey_nova_me.wav`

Run on a device/emulator: `./gradlew connectedDebugAndroidTest`
