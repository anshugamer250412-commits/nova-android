package com.nova.assistant.actions

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import com.nova.assistant.parser.SearchPlatform
import java.net.URLEncoder

class SearchLauncher(private val context: Context) {

    fun executeSearch(query: String, platform: SearchPlatform): Result<String> {
        val trimmedQuery = query.trim()
        if (trimmedQuery.isEmpty()) {
            return Result.failure(IllegalArgumentException("Search query cannot be empty"))
        }

        return try {
            val encoded = URLEncoder.encode(trimmedQuery, "UTF-8")
            when (platform) {
                SearchPlatform.GOOGLE -> {
                    // Try web search intent first
                    val searchIntent = Intent(Intent.ACTION_WEB_SEARCH).apply {
                        putExtra(SearchManager.QUERY, trimmedQuery)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    if (searchIntent.resolveActivity(context.packageManager) != null) {
                        context.startActivity(searchIntent)
                        Result.success("Searching Google for $trimmedQuery")
                    } else {
                        // Browser URL fallback
                        val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=$encoded")).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(browserIntent)
                        Result.success("Opened Google search for $trimmedQuery")
                    }
                }

                SearchPlatform.YOUTUBE -> {
                    // Standard YouTube app search intent
                    val ytAppIntent = Intent(Intent.ACTION_SEARCH).apply {
                        setPackage("com.google.android.youtube")
                        putExtra("query", trimmedQuery)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }

                    if (ytAppIntent.resolveActivity(context.packageManager) != null) {
                        context.startActivity(ytAppIntent)
                        Result.success("Searching YouTube for $trimmedQuery")
                    } else {
                        // Standard YouTube URL deep link (opens YouTube app if installed, browser otherwise)
                        val webYtIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=$encoded")).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(webYtIntent)
                        Result.success("Opened YouTube search for $trimmedQuery")
                    }
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
