package com.nova.assistant.wakeword

import android.content.Context
import android.util.Log
import org.json.JSONArray
import org.vosk.LibVosk
import org.vosk.LogLevel
import org.vosk.Model
import org.vosk.Recognizer

/** Lifecycle of a wake-word engine. */
enum class WakeWordState {
    UNINITIALIZED,
    MISSING_MODEL,
    INITIALIZING,
    READY,
    ERROR
}

/**
 * Keyword-spotting contract.
 *
 * - [processAudioFrame] consumes 16 kHz, 16-bit, mono PCM and returns true ONLY when the spoken
 *   wake phrase has been recognised by the speech decoder. Loudness / RMS / voice activity are never
 *   used as a detection signal.
 * - [initialize] is blocking (copies + loads a ~40 MB model): never call it on the main thread.
 */
interface WakeWordEngine {
    val name: String
    val keyword: String
    val isReady: Boolean
    val state: WakeWordState
    val lastError: String?

    fun initialize(context: Context? = null): Result<Unit>

    /** Clears decoder state so audio from a previous listening session cannot leak into the next one. */
    fun resetSession()

    fun processAudioFrame(pcmData: ShortArray, length: Int = pcmData.size): Boolean

    fun release()
}

/** Thrown when the offline wake-word model is missing, incomplete, or cannot represent the phrase. */
class WakeWordModelException(message: String) : Exception(message)

/**
 * On-device "Hey NOVA" detector built directly on the Vosk Android API (org.vosk.Model / Recognizer).
 *
 * Model:  vosk-model-small-en-us-0.15 (Apache 2.0) - https://alphacephei.com/vosk/models
 * Mode:   Recognizer(model, 16000f, grammar) with grammar ["hey nova", "[unk]"]. The decoder may
 *         only output the wake phrase or the "[unk]" filler, which rejects ordinary speech.
 * Audio:  16 000 Hz, mono, PCM 16-bit (see [SAMPLE_RATE_HZ]).
 * Result: a detection needs the decoder to output the words "hey nova" consecutively, with every
 *         word at or above [minWordConfidence] when Vosk reports word confidences.
 *
 * Thread-safety: all native access is serialised on [lock], so [release] can never free the native
 * model while a frame is being decoded.
 */
class VoskWakeWordEngine(
    override val keyword: String = "Hey NOVA",
    private val modelAssetDir: String = WakeWordModelStore.DEFAULT_MODEL_ASSET_DIR,
    private val minWordConfidence: Float = DEFAULT_MIN_WORD_CONFIDENCE
) : WakeWordEngine {

    override val name: String = "Vosk Wake-Word Spotter (vosk-model-small-en-us-0.15)"

    @Volatile
    override var isReady: Boolean = false
        private set

    @Volatile
    override var state: WakeWordState = WakeWordState.UNINITIALIZED
        private set

    @Volatile
    override var lastError: String? = null
        private set

    private val lock = Any()
    private var model: Model? = null
    private var recognizer: Recognizer? = null

    override fun initialize(context: Context?): Result<Unit> =
        synchronized(lock) { initializeLocked(context) }

    private fun initializeLocked(context: Context?): Result<Unit> {
        if (isReady && model != null && recognizer != null) return Result.success(Unit)

        closeNativeLocked()
        state = WakeWordState.INITIALIZING
        lastError = null

        if (context == null) {
            return fail(WakeWordState.ERROR, "Android Context is required to load the wake-word model", null)
        }

        val modelDir = WakeWordModelStore.install(context.applicationContext, modelAssetDir)
            .getOrElse { return fail(WakeWordState.MISSING_MODEL, it.message ?: "Wake-word model unavailable", it) }

        var loadedModel: Model? = null
        var loadedRecognizer: Recognizer? = null
        try {
            LibVosk.setLogLevel(LogLevel.WARNINGS)
            loadedModel = Model(modelDir.absolutePath)
            loadedRecognizer = createRecognizer(loadedModel)
        } catch (e: Exception) {
            loadedRecognizer?.close()
            loadedModel?.close()
            return fail(WakeWordState.ERROR, "Vosk could not load the model: ${e.message}", e)
        } catch (e: LinkageError) { // e.g. UnsatisfiedLinkError when libvosk.so / JNA is missing for this ABI
            loadedRecognizer?.close()
            loadedModel?.close()
            return fail(WakeWordState.ERROR, "Vosk native library unavailable: ${e.message}", e)
        }

        model = loadedModel
        recognizer = loadedRecognizer
        isReady = true
        state = WakeWordState.READY
        Log.i(TAG, "Vosk wake-word engine ready (model=${modelDir.absolutePath}, keyword='$keyword', rate=${SAMPLE_RATE_HZ}Hz)")
        return Result.success(Unit)
    }

    private fun createRecognizer(model: Model): Recognizer {
        val grammar = JSONArray().put(keyword.trim().lowercase()).put(WakePhraseMatcher.UNKNOWN_TOKEN).toString()
        return Recognizer(model, SAMPLE_RATE_HZ.toFloat(), grammar).also { it.setWords(true) }
    }

    override fun resetSession() {
        synchronized(lock) {
            try {
                recognizer?.reset()
            } catch (e: Exception) {
                Log.w(TAG, "Recognizer reset failed", e)
            }
        }
    }

    /**
     * Feeds [length] samples of 16 kHz mono PCM16 to the decoder.
     * Returns true only if the decoder produced the wake phrase.
     */
    override fun processAudioFrame(pcmData: ShortArray, length: Int): Boolean =
        synchronized(lock) {
            val rec = recognizer
            if (!isReady || rec == null || length <= 0) {
                false
            } else {
                try {
                    if (rec.acceptWaveForm(pcmData, length)) {
                        // Endpoint reached: the utterance is final.
                        val detected = isWakePhrase(rec.result)
                        if (detected) rec.reset()
                        detected
                    } else if (WakePhraseMatcher.containsPhrase(
                            WakePhraseMatcher.parsePartial(rec.partialResult), keyword
                        )
                    ) {
                        // The phrase is already in the live hypothesis: flush to obtain per-word
                        // confidences and decide now instead of waiting for trailing silence.
                        val detected = isWakePhrase(rec.finalResult)
                        rec.reset()
                        detected
                    } else {
                        false
                    }
                } catch (e: Exception) {
                    lastError = "Decoder error: ${e.message}"
                    Log.e(TAG, "Vosk decoding failed", e)
                    false
                }
            }
        }

    private fun isWakePhrase(resultJson: String): Boolean {
        val hypothesis = WakePhraseMatcher.parseResult(resultJson)
        val matched = WakePhraseMatcher.isWakeWord(hypothesis, keyword, minWordConfidence)
        if (hypothesis.text.isNotBlank()) {
            Log.d(TAG, "Vosk hypothesis='${hypothesis.text}' words=${hypothesis.words} matched=$matched")
        }
        return matched
    }

    override fun release() {
        synchronized(lock) {
            closeNativeLocked()
            isReady = false
            state = WakeWordState.UNINITIALIZED
        }
    }

    private fun closeNativeLocked() {
        try {
            recognizer?.close()
        } catch (e: Exception) {
            Log.w(TAG, "Error closing Vosk recognizer", e)
        }
        try {
            model?.close()
        } catch (e: Exception) {
            Log.w(TAG, "Error closing Vosk model", e)
        }
        recognizer = null
        model = null
        isReady = false
    }

    private fun fail(newState: WakeWordState, message: String, cause: Throwable?): Result<Unit> {
        isReady = false
        state = newState
        lastError = message
        Log.e(TAG, message, cause)
        return Result.failure(cause ?: WakeWordModelException(message))
    }

    companion object {
        private const val TAG = "VoskWakeWordEngine"

        /** Vosk models are trained for 16 kHz audio; AudioRecord must use the same rate. */
        const val SAMPLE_RATE_HZ = 16000

        /**
         * Minimum per-word confidence reported by Vosk. NOTE: not yet calibrated on real devices -
         * see the instrumented test, which logs the confidences it observes.
         */
        const val DEFAULT_MIN_WORD_CONFIDENCE = 0.5f
    }
}
