package com.nova.assistant.ai

/**
 * Structured Action Schema returned by AI providers.
 * Enforces strict typing and prevents execution of unapproved commands.
 */
data class AiActionRequest(
    val actionType: String,
    val parameters: Map<String, String> = emptyMap(),
    val speechResponse: String,
    val reasoning: String = ""
)
