package com.nova.assistant.parser

sealed class CommandResult {
    abstract val feedbackSpeech: String
    abstract val displayTitle: String

    data class Success(
        override val feedbackSpeech: String,
        override val displayTitle: String,
        val detail: String = ""
    ) : CommandResult()

    data class Failure(
        override val feedbackSpeech: String,
        val errorMessage: String,
        override val displayTitle: String = errorMessage
    ) : CommandResult()

    data class NeedsConfirmation(
        val prompt: String,
        val pendingCommand: NovaCommand,
        override val feedbackSpeech: String = prompt,
        override val displayTitle: String = "Confirmation Needed"
    ) : CommandResult()
}
