package com.nova.assistant.parser

enum class SearchPlatform {
    GOOGLE,
    YOUTUBE
}

enum class VolumeDirection {
    UP,
    DOWN,
    MUTE
}

enum class AccessibilityActionType {
    SCROLL_UP,
    SCROLL_DOWN,
    TAP_ELEMENT,
    TYPE_TEXT,
    GO_BACK,
    GO_HOME
}

sealed class SettingTarget(val nameKey: String) {
    object Wifi : SettingTarget("wifi")
    object Bluetooth : SettingTarget("bluetooth")
    object Display : SettingTarget("display")
    object Sound : SettingTarget("sound")
    object Battery : SettingTarget("battery")
    object Apps : SettingTarget("apps")
    object Accessibility : SettingTarget("accessibility")
    object Location : SettingTarget("location")
    object General : SettingTarget("general")
}

sealed class NovaCommand {
    data class OpenApp(val appQuery: String) : NovaCommand()
    data class WebSearch(val query: String, val platform: SearchPlatform = SearchPlatform.GOOGLE) : NovaCommand()
    data class PlayStoreSearch(val query: String = "") : NovaCommand()
    data class CallContact(val contactName: String) : NovaCommand()
    data class SendWhatsAppMessage(val recipient: String, val message: String = "") : NovaCommand()
    data class ToggleFlashlight(val desiredState: Boolean? = null) : NovaCommand()
    data class AdjustVolume(val direction: VolumeDirection) : NovaCommand()
    data class OpenSettings(val target: SettingTarget) : NovaCommand()
    data class SystemStatus(val metric: String) : NovaCommand()
    data class AccessibilityAction(val type: AccessibilityActionType, val parameter: String = "") : NovaCommand()
    data class QueryAi(val question: String) : NovaCommand()
    data object ShowHistory : NovaCommand()
    data object ShowHelp : NovaCommand()
    data class Unknown(val rawInput: String) : NovaCommand()
}
