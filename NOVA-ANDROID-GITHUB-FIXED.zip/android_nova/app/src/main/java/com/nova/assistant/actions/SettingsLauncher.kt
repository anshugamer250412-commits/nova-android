package com.nova.assistant.actions

import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import com.nova.assistant.parser.SettingTarget

class SettingsLauncher(private val context: Context) {

    fun open(target: SettingTarget): Result<String> = launchSettings(target)

    fun launchSettings(target: SettingTarget): Result<String> {
        return try {
            val intent = when (target) {
                SettingTarget.Wifi -> {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        try {
                            Intent(Settings.Panel.ACTION_WIFI)
                        } catch (e: Exception) {
                            Intent(Settings.ACTION_WIFI_SETTINGS)
                        }
                    } else {
                        Intent(Settings.ACTION_WIFI_SETTINGS)
                    }
                }
                SettingTarget.Bluetooth -> Settings.ACTION_BLUETOOTH_SETTINGS.let { Intent(it) }
                SettingTarget.Display -> Settings.ACTION_DISPLAY_SETTINGS.let { Intent(it) }
                SettingTarget.Sound -> Settings.ACTION_SOUND_SETTINGS.let { Intent(it) }
                SettingTarget.Battery -> Settings.ACTION_BATTERY_SAVER_SETTINGS.let { Intent(it) }
                SettingTarget.Apps -> Settings.ACTION_APPLICATION_SETTINGS.let { Intent(it) }
                SettingTarget.Accessibility -> Settings.ACTION_ACCESSIBILITY_SETTINGS.let { Intent(it) }
                SettingTarget.Location -> Settings.ACTION_LOCATION_SOURCE_SETTINGS.let { Intent(it) }
                SettingTarget.General -> Settings.ACTION_SETTINGS.let { Intent(it) }
            }.apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }

            if (intent.resolveActivity(context.packageManager) != null) {
                context.startActivity(intent)
                Result.success("Opened ${target.nameKey} settings")
            } else {
                val fallbackIntent = Intent(Settings.ACTION_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(fallbackIntent)
                Result.success("Opened system settings")
            }
        } catch (e: Exception) {
            try {
                val fallbackIntent = Intent(Settings.ACTION_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(fallbackIntent)
                Result.success("Opened general settings")
            } catch (err: Exception) {
                Result.failure(err)
            }
        }
    }
}
