package com.nova.assistant.service

/**
 * AssistantStateMachine provides an authoritative, guarded state machine
 * for the NOVA assistant voice lifecycle.
 *
 * Preferred lifecycle:
 * STOPPED -> STARTING -> WAKE_WORD_LISTENING -> COMMAND_LISTENING -> PROCESSING -> SPEAKING -> WAKE_WORD_LISTENING
 *
 * Guarantees:
 * - Rejects illegal transitions
 * - Enforces single exclusive session ID to prevent competing capture sessions
 * - Guards command execution against duplicate partial/final recognition callbacks
 * - Bounded recovery on recognition errors
 */
class AssistantStateMachine(
    initialPhase: AssistantPhase = AssistantPhase.STOPPED
) {
    var currentPhase: AssistantPhase = initialPhase
        private set

    var activeSessionId: Long = 0L
        private set

    private var executedCommandSessionId: Long = -1L
    var errorRecoveryAttempts: Int = 0
        private set

    val maxErrorRecoveryAttempts: Int = 3

    fun canTransitionTo(next: AssistantPhase): Boolean {
        return when (currentPhase) {
            AssistantPhase.STOPPED -> next == AssistantPhase.STARTING
            AssistantPhase.STARTING -> next == AssistantPhase.WAKE_WORD_LISTENING ||
                    next == AssistantPhase.COMMAND_LISTENING ||
                    next == AssistantPhase.ERROR ||
                    next == AssistantPhase.STOPPED

            AssistantPhase.WAKE_WORD_LISTENING -> next == AssistantPhase.COMMAND_LISTENING ||
                    next == AssistantPhase.PROCESSING ||
                    next == AssistantPhase.SPEAKING ||
                    next == AssistantPhase.STOPPED ||
                    next == AssistantPhase.ERROR

            AssistantPhase.COMMAND_LISTENING -> next == AssistantPhase.PROCESSING ||
                    next == AssistantPhase.WAKE_WORD_LISTENING ||
                    next == AssistantPhase.STOPPED ||
                    next == AssistantPhase.ERROR

            AssistantPhase.PROCESSING -> next == AssistantPhase.SPEAKING ||
                    next == AssistantPhase.WAKE_WORD_LISTENING ||
                    next == AssistantPhase.STOPPED ||
                    next == AssistantPhase.ERROR

            AssistantPhase.SPEAKING -> next == AssistantPhase.WAKE_WORD_LISTENING ||
                    next == AssistantPhase.COMMAND_LISTENING ||
                    next == AssistantPhase.STOPPED ||
                    next == AssistantPhase.ERROR

            AssistantPhase.ERROR -> next == AssistantPhase.WAKE_WORD_LISTENING ||
                    next == AssistantPhase.COMMAND_LISTENING ||
                    next == AssistantPhase.STARTING ||
                    next == AssistantPhase.STOPPED
        }
    }

    fun transitionTo(next: AssistantPhase): Boolean {
        if (!canTransitionTo(next)) {
            return false
        }
        currentPhase = next
        if (next == AssistantPhase.WAKE_WORD_LISTENING) {
            errorRecoveryAttempts = 0
            executedCommandSessionId = -1L
        }
        return true
    }

    fun startNewSession(): Long {
        activeSessionId++
        transitionTo(AssistantPhase.STARTING)
        return activeSessionId
    }

    fun stopSession() {
        currentPhase = AssistantPhase.STOPPED
        executedCommandSessionId = -1L
        errorRecoveryAttempts = 0
    }

    /**
     * Guards command execution to guarantee that duplicate recognition callbacks
     * cannot execute the same command session twice.
     */
    fun beginCommandExecution(sessionId: Long): Boolean {
        if (sessionId != activeSessionId) return false
        if (executedCommandSessionId == sessionId) return false
        if (currentPhase != AssistantPhase.PROCESSING) return false

        executedCommandSessionId = sessionId
        return true
    }

    /**
     * Bounded error recovery. Returns true if retry is within bounded limits,
     * false if max recovery attempts exceeded.
     */
    fun handleRecognitionError(isFatalPermission: Boolean): Boolean {
        if (isFatalPermission) {
            currentPhase = AssistantPhase.ERROR
            return false
        }
        errorRecoveryAttempts++
        return if (errorRecoveryAttempts <= maxErrorRecoveryAttempts) {
            currentPhase = AssistantPhase.WAKE_WORD_LISTENING
            true
        } else {
            currentPhase = AssistantPhase.ERROR
            false
        }
    }
}
