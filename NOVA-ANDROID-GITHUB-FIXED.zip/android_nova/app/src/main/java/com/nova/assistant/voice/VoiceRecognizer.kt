package com.nova.assistant.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

class VoiceRecognizer(
    private val context: Context,
    private val onResultRecognized: (String) -> Unit
) : RecognitionListener {

    private val tag = "VoiceRecognizer"
    private var speechRecognizer: SpeechRecognizer? = null

    private val _state = MutableStateFlow<SpeechState>(SpeechState.Idle)
    val state: StateFlow<SpeechState> = _state.asStateFlow()

    private val _rmsDb = MutableStateFlow(0f)
    val rmsDb: StateFlow<Float> = _rmsDb.asStateFlow()

    init {
        initRecognizer()
    }

    private fun initRecognizer() {
        if (SpeechRecognizer.isRecognitionAvailable(context)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                setRecognitionListener(this@VoiceRecognizer)
            }
        } else {
            Log.w(tag, "Speech recognition service is not available on this device")
            _state.value = SpeechState.Error("Speech recognition service unavailable on this device")
        }
    }

    fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            _state.value = SpeechState.Error("Device does not have a speech recognition service installed.")
            return
        }

        if (speechRecognizer == null) {
            initRecognizer()
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
        }

        try {
            speechRecognizer?.startListening(intent)
            _state.value = SpeechState.Listening
        } catch (e: Exception) {
            Log.e(tag, "Error starting speech listening", e)
            _state.value = SpeechState.Error("Failed to start voice listener: ${e.message}")
        }
    }

    fun stopListening() {
        try {
            speechRecognizer?.stopListening()
            if (_state.value is SpeechState.Listening) {
                _state.value = SpeechState.Processing()
            }
        } catch (e: Exception) {
            Log.e(tag, "Error stopping listening", e)
        }
    }

    fun cancel() {
        try {
            speechRecognizer?.cancel()
            _state.value = SpeechState.Idle
        } catch (e: Exception) {
            Log.e(tag, "Error canceling listening", e)
        }
    }

    fun destroy() {
        try {
            speechRecognizer?.destroy()
            speechRecognizer = null
        } catch (e: Exception) {
            Log.e(tag, "Error destroying recognizer", e)
        }
    }

    override fun onReadyForSpeech(params: Bundle?) {
        _state.value = SpeechState.Listening
    }

    override fun onBeginningOfSpeech() {
        _state.value = SpeechState.Listening
    }

    override fun onRmsChanged(rmsdB: Float) {
        _rmsDb.value = rmsdB
    }

    override fun onBufferReceived(buffer: ByteArray?) {}

    override fun onEndOfSpeech() {
        _state.value = SpeechState.Processing()
    }

    override fun onError(error: Int) {
        val errorMessage = when (error) {
            SpeechRecognizer.ERROR_AUDIO -> "Audio recording error"
            SpeechRecognizer.ERROR_CLIENT -> "Client-side recognition error"
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is required"
            SpeechRecognizer.ERROR_NETWORK -> "Network connection error for speech recognition"
            SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network timeout"
            SpeechRecognizer.ERROR_NO_MATCH -> "No speech recognized. Please try again."
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Speech recognizer is busy"
            SpeechRecognizer.ERROR_SERVER -> "Speech server error"
            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech detected"
            else -> "Speech recognition error code: $error"
        }
        Log.w(tag, "Speech recognition error: $errorMessage ($error)")
        _state.value = SpeechState.Error(errorMessage, error)
    }

    override fun onResults(results: Bundle?) {
        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        val recognized = matches?.firstOrNull()?.trim()

        if (!recognized.isNullOrEmpty()) {
            _state.value = SpeechState.Processing(recognized)
            onResultRecognized(recognized)
        } else {
            _state.value = SpeechState.Error("Could not recognize any spoken command")
        }
    }

    override fun onPartialResults(partialResults: Bundle?) {
        val partialMatches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        val partialText = partialMatches?.firstOrNull() ?: ""
        if (partialText.isNotEmpty()) {
            _state.value = SpeechState.Processing(partialText)
        }
    }

    override fun onEvent(eventType: Int, params: Bundle?) {}
}
