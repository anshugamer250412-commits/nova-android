package com.nova.assistant.parser

import java.util.Locale

class CommandParser {

    /**
     * Parses raw user spoken or typed query into a strongly typed NovaCommand.
     * Supports natural variations in English, Hindi, and Hinglish completely offline.
     */
    fun parse(rawText: String): NovaCommand {
        val trimmed = rawText.trim()
        if (trimmed.isEmpty()) {
            return NovaCommand.Unknown("")
        }

        // 0. Strip common wake word prefixes if user speaks wake word + command together
        var normalized = trimmed.lowercase(Locale.ROOT)
        normalized = normalized
            .replace(Regex("""^(?:hey|hi|hello|ok|okay)?\s*nova[,:\s]*"""), "")
            .trim()

        // Strip leading and trailing punctuation marks safely
        normalized = normalized.replace(Regex("""^[\s,.:;!?-]+|[\s,.:;!?-]+$"""), "").trim()

        if (normalized.isEmpty()) {
            return NovaCommand.Unknown(rawText)
        }

        // 1. Wi-Fi Commands (Direct toggles restricted on Android 10+; routes to safe settings panel)
        val wifiRegex = Regex("""\b(?:turn\s+(?:on|off)|enable|disable|switch\s+(?:on|off)|chalu|band)?\s*(?:the\s+)?(?:wi-?fi|wifi|internet|network)(?:\s+(?:on|off|chalu|band|kholo|settings?|options?|chalu\s+karo|band\s+karo))?\b|^wi-?fi$""")
        if (wifiRegex.containsMatchIn(normalized) && (normalized.contains("on") || normalized.contains("off") || normalized.contains("wifi") || normalized.contains("wi-fi") || normalized.contains("karo") || normalized.contains("setting"))) {
            return NovaCommand.OpenSettings(SettingTarget.Wifi)
        }

        // 2. Bluetooth Commands (Direct toggles restricted on modern Android; routes to Bluetooth settings)
        val bluetoothRegex = Regex("""\b(?:turn\s+(?:on|off)|enable|disable|switch\s+(?:on|off)|chalu|band)?\s*(?:the\s+)?(?:bluetooth|bt)(?:\s+(?:on|off|chalu|band|kholo|settings?|options?|chalu\s+karo|band\s+karo))?\b|^bluetooth$""")
        if (bluetoothRegex.containsMatchIn(normalized) && (normalized.contains("on") || normalized.contains("off") || normalized.contains("bluetooth") || normalized.contains("bt") || normalized.contains("karo") || normalized.contains("setting"))) {
            return NovaCommand.OpenSettings(SettingTarget.Bluetooth)
        }

        // 3. Play Store Search / Download / Install Commands
        val playStoreSearchRegex = Regex("""^(?:open\s+play\s*store\s+(?:and\s+)?(?:find|search(?:\s+for)?)|search\s+play\s*store(?:\s+for)?|find\s+(.*?)\s+on\s+play\s*store|download|install|play\s*store\s+(?:par|pe|mein|me)\s+(.*?)\s+(?:search\s+karo|dhoondo|search))\s*(.*)$""")
        val playMatch = playStoreSearchRegex.find(normalized)
        if (playMatch != null) {
            val queryCandidate = (playMatch.groupValues[1].ifEmpty {
                playMatch.groupValues[2].ifEmpty {
                    playMatch.groupValues[3]
                }
            }).trim()
            val cleanedQuery = queryCandidate
                .removePrefix("for ")
                .removePrefix("app ")
                .removePrefix("the ")
                .removeSuffix(" on play store")
                .removeSuffix(" on playstore")
                .replace(Regex("""^[\s,.:;!?-]+|[\s,.:;!?-]+$"""), "")
                .trim()
            if (cleanedQuery.isNotEmpty() && cleanedQuery != "kholo" && cleanedQuery != "open") {
                return NovaCommand.PlayStoreSearch(cleanedQuery)
            }
        }

        // "Play Store kholo" / "Open Play Store"
        if (normalized == "play store kholo" || normalized == "playstore kholo" || normalized == "open play store" || normalized == "open playstore") {
            return NovaCommand.OpenApp("play store")
        }

        // 4. YouTube Search Commands (Natural variations)
        val ytHindiRegex = Regex("""^youtube\s+(?:par|pe|mein|me)\s+(.+?)(?:\s+(?:search\s+karo|chalao|dhoondo|dikhao|search))?$""")
        val ytHindiMatch = ytHindiRegex.find(normalized)
        if (ytHindiMatch != null) {
            var query = ytHindiMatch.groupValues[1].trim()
            query = query.replace(Regex("""^[\s,.:;!?-]+|[\s,.:;!?-]+$"""), "").trim()
            if (query.isNotEmpty() && query != "kholo" && query != "open") {
                return NovaCommand.WebSearch(query, SearchPlatform.YOUTUBE)
            }
        }

        val ytOnRegex = Regex("""^(?:search(?:\s+for)?|play)\s+(.*?)\s+on\s+youtube$""")
        val ytOnMatch = ytOnRegex.find(normalized)
        if (ytOnMatch != null) {
            val query = ytOnMatch.groupValues[1].removePrefix("for ").replace(Regex("""^[\s,.:;!?-]+|[\s,.:;!?-]+$"""), "").trim()
            if (query.isNotEmpty()) {
                return NovaCommand.WebSearch(query, SearchPlatform.YOUTUBE)
            }
        }

        val ytSearchPrefixRegex = Regex("""^(?:search\s+youtube(?:\s+for)?|youtube\s+search(?:\s+for)?|open\s+youtube\s+and\s+search(?:\s+for)?)\s+(.+)$""")
        val ytPrefixMatch = ytSearchPrefixRegex.find(normalized)
        if (ytPrefixMatch != null) {
            val query = ytPrefixMatch.groupValues[1].removePrefix("for ").replace(Regex("""^[\s,.:;!?-]+|[\s,.:;!?-]+$"""), "").trim()
            if (query.isNotEmpty()) {
                return NovaCommand.WebSearch(query, SearchPlatform.YOUTUBE)
            }
        }

        // 5. Flashlight / Torch Commands (English + Hindi/Hinglish)
        val flashlightOnRegex = Regex("""\b(?:turn\s+on|enable|activate|switch\s+on|jalao|chalu\s+karo)\s+(?:the\s+)?(?:flashlight|torch)\b|\b(?:flashlight|torch)\s+(?:on|chalu|jalao|start)(?:\s+(?:karo|kar\s+do))?\b""")
        val flashlightOffRegex = Regex("""\b(?:turn\s+off|disable|deactivate|switch\s+off|bujhao|band\s+karo|band\s+kar\s+do)\s+(?:the\s+)?(?:flashlight|torch)\b|\b(?:flashlight|torch)\s+(?:off|band|bujhao)(?:\s+(?:karo|kar\s+do))?\b""")
        val flashlightToggleRegex = Regex("""\b(?:toggle|switch)\s+(?:the\s+)?(?:flashlight|torch)\b|^(?:flashlight|torch)$""")

        if (flashlightOnRegex.containsMatchIn(normalized)) {
            return NovaCommand.ToggleFlashlight(desiredState = true)
        }
        if (flashlightOffRegex.containsMatchIn(normalized)) {
            return NovaCommand.ToggleFlashlight(desiredState = false)
        }
        if (flashlightToggleRegex.containsMatchIn(normalized)) {
            return NovaCommand.ToggleFlashlight(desiredState = null)
        }

        // 6. Volume Adjustments (English + Hindi/Hinglish)
        val volumeDownRegex = Regex("""\b(?:volume|aawaz|awaaz|sound)\s+(?:kam|down|ghatao|dheemi)(?:\s+karo)?\b|\b(?:volume\s+down|lower\s+volume|decrease\s+volume)\b""")
        val volumeUpRegex = Regex("""\b(?:volume|aawaz|awaaz|sound)\s+(?:badhao|up|tez|increase)(?:\s+karo)?\b|\b(?:volume\s+up|raise\s+volume|increase\s+volume)\b""")
        val volumeMuteRegex = Regex("""\b(?:mute|silent|chup\s+karo)\b""")

        if (volumeDownRegex.containsMatchIn(normalized)) {
            return NovaCommand.AdjustVolume(VolumeDirection.DOWN)
        }
        if (volumeUpRegex.containsMatchIn(normalized)) {
            return NovaCommand.AdjustVolume(VolumeDirection.UP)
        }
        if (volumeMuteRegex.containsMatchIn(normalized)) {
            return NovaCommand.AdjustVolume(VolumeDirection.MUTE)
        }

        // 7. Contacts & Calling (English + Hindi/Hinglish)
        val findContactRegex = Regex("""^(?:find|search(?:\s+for)?)\s+([a-z0-9\s._-]+?)\s+(?:in\s+(?:my\s+)?contacts|phonebook)$""")
        val findContactMatch = findContactRegex.find(normalized)
        if (findContactMatch != null) {
            val contactName = findContactMatch.groupValues[1].replace(Regex("""^[\s,.:;!?-]+|[\s,.:;!?-]+$"""), "").trim()
            if (contactName.isNotEmpty()) {
                return NovaCommand.CallContact(contactName)
            }
        }

        val hindiCallRegex = Regex("""^(.*?)\s+ko\s+(?:call|phone)\s+(?:karo|lagao|milao|kar\s+do)$""")
        val hindiCallMatch = hindiCallRegex.find(normalized)
        if (hindiCallMatch != null) {
            val contactName = hindiCallMatch.groupValues[1].replace(Regex("""^[\s,.:;!?-]+|[\s,.:;!?-]+$"""), "").trim()
            if (contactName.isNotEmpty()) {
                return NovaCommand.CallContact(contactName)
            }
        }

        val englishCallRegex = Regex("""^(?:call|dial|phone)\s+(?:to\s+)?([a-z0-9\s._-]+)$""")
        val englishCallMatch = englishCallRegex.find(normalized)
        if (englishCallMatch != null) {
            val contactName = englishCallMatch.groupValues[1].replace(Regex("""^[\s,.:;!?-]+|[\s,.:;!?-]+$"""), "").trim()
            if (contactName.isNotEmpty() && !contactName.contains("setting") && contactName != "me") {
                return NovaCommand.CallContact(contactName)
            }
        }

        // 8. General Settings
        if (Regex("""\b(?:open|launch|show|go to)\s+(?:the\s+)?settings$|^(?:settings?\s+(?:kholo|dikhao)|open\s+settings)$""").containsMatchIn(normalized)) {
            return NovaCommand.OpenSettings(SettingTarget.General)
        }

        // 9. Time Query
        if (normalized.contains("kitne baje") || normalized.contains("time kya") || normalized.contains("what time") || normalized.contains("current time")) {
            return NovaCommand.SystemStatus("time")
        }

        // 10. General Web Search (Google)
        val googleOnRegex = Regex("""^(?:search(?:\s+for)?)\s+(.*?)\s+on\s+google$""")
        val googleOnMatch = googleOnRegex.find(normalized)
        if (googleOnMatch != null) {
            val query = googleOnMatch.groupValues[1].removePrefix("for ").replace(Regex("""^[\s,.:;!?-]+|[\s,.:;!?-]+$"""), "").trim()
            if (query.isNotEmpty()) {
                return NovaCommand.WebSearch(query, SearchPlatform.GOOGLE)
            }
        }

        val hindiGoogleRegex = Regex("""^(?:google|web|chrome)\s+(?:par|pe)\s+(.*?)\s+search\s+karo$""")
        val hindiGoogleMatch = hindiGoogleRegex.find(normalized)
        if (hindiGoogleMatch != null) {
            val query = hindiGoogleMatch.groupValues[1].replace(Regex("""^[\s,.:;!?-]+|[\s,.:;!?-]+$"""), "").trim()
            if (query.isNotEmpty()) {
                return NovaCommand.WebSearch(query, SearchPlatform.GOOGLE)
            }
        }

        val englishSearchRegex = Regex("""^(?:search|look\s+up|find)\s+(?:(?:google|the\s+web)\s+(?:for\s+)?)?(.*?)$""")
        val englishSearchMatch = englishSearchRegex.find(normalized)
        if (englishSearchMatch != null) {
            val query = englishSearchMatch.groupValues[1].trim()
            if (query.isNotEmpty() && (normalized.startsWith("search") || normalized.startsWith("look up") || normalized.startsWith("find"))) {
                val cleanedQuery = query.removePrefix("for ").replace(Regex("""^[\s,.:;!?-]+|[\s,.:;!?-]+$"""), "").trim()
                if (cleanedQuery.isNotEmpty()) {
                    return NovaCommand.WebSearch(cleanedQuery, SearchPlatform.GOOGLE)
                }
            }
        }

        // 11. WhatsApp Messages
        val whatsappMsgRegex = Regex("""^(?:send\s+whatsapp\s+(?:message\s+)?to\s+|(.*?)\s+ko\s+whatsapp\s+karo)(.*)$""")
        val waMatch = whatsappMsgRegex.find(normalized)
        if (waMatch != null) {
            val recipient = (waMatch.groupValues[1].ifEmpty { "someone" }).trim()
            val message = waMatch.groupValues[2].trim()
            return NovaCommand.SendWhatsAppMessage(recipient, message)
        }

        // 12. Settings Sub-pages
        val settingsPrefixRegex = Regex("""\b(?:open|launch|show|go to)\s+(?:the\s+)?(.*?)(\s+settings|\s+options)?$|(.*?)\s+settings?\s+(?:kholo|dikhao)$""")
        val settingsMatch = settingsPrefixRegex.find(normalized)
        if (settingsMatch != null) {
            val target = (settingsMatch.groupValues[1].ifEmpty { settingsMatch.groupValues[3] }).trim()
            val isExplicitSettings = normalized.contains("setting") || normalized.startsWith("go to") || normalized.startsWith("show")

            val mappedSetting = when {
                target.contains("wifi") || target.contains("wi-fi") || target.contains("internet") || target.contains("network") -> SettingTarget.Wifi
                target.contains("bluetooth") || target.contains("bt") -> SettingTarget.Bluetooth
                target.contains("display") || target.contains("screen") || target.contains("brightness") -> SettingTarget.Display
                target.contains("sound") || target.contains("volume") || target.contains("audio") -> SettingTarget.Sound
                target.contains("battery") || target.contains("power") -> SettingTarget.Battery
                target.contains("apps") || target.contains("applications") || target.contains("app manager") -> SettingTarget.Apps
                target.contains("accessibility") || target.contains("talkback") -> SettingTarget.Accessibility
                target.contains("location") || target.contains("gps") -> SettingTarget.Location
                target.isEmpty() && isExplicitSettings -> SettingTarget.General
                target == "settings" || target == "setting" -> SettingTarget.General
                else -> null
            }
            if (mappedSetting != null) {
                return NovaCommand.OpenSettings(mappedSetting)
            }
        }

        // 13. On-Screen Accessibility Gestures
        if (normalized.contains("scroll down") || normalized.contains("neeche scroll")) {
            return NovaCommand.AccessibilityAction(AccessibilityActionType.SCROLL_DOWN)
        }
        if (normalized.contains("scroll up") || normalized.contains("upar scroll")) {
            return NovaCommand.AccessibilityAction(AccessibilityActionType.SCROLL_UP)
        }
        if (normalized == "go back" || normalized == "back" || normalized == "peeche jao") {
            return NovaCommand.AccessibilityAction(AccessibilityActionType.GO_BACK)
        }
        if (normalized == "go home" || normalized == "home" || normalized == "home screen jao") {
            return NovaCommand.AccessibilityAction(AccessibilityActionType.GO_HOME)
        }

        // 14. Application Launch Commands
        val hindiAppLaunch = Regex("""^(?:the\s+)?([a-z0-9\s._-]+)\s+(?:kholo|open\s+karo|chalu\s+karo)$""")
        val hindiAppMatch = hindiAppLaunch.find(normalized)
        if (hindiAppMatch != null) {
            val appQuery = hindiAppMatch.groupValues[1].replace(Regex("""^[\s,.:;!?-]+|[\s,.:;!?-]+$"""), "").trim()
            if (appQuery.isNotEmpty() && !appQuery.contains("setting")) {
                return NovaCommand.OpenApp(appQuery)
            }
        }

        val appLaunchRegex = Regex("""^(?:open|launch|start|run|play)\s+(?:the\s+)?([a-z0-9\s._-]+)$""")
        val appMatch = appLaunchRegex.find(normalized)
        if (appMatch != null) {
            val appQuery = appMatch.groupValues[1].replace(Regex("""^[\s,.:;!?-]+|[\s,.:;!?-]+$"""), "").trim()
            if (appQuery.isNotEmpty() && !appQuery.contains("setting")) {
                return NovaCommand.OpenApp(appQuery)
            }
        }

        // Popular direct app names
        val popularApps = setOf("youtube", "instagram", "camera", "calculator", "calendar", "chrome", "maps", "spotify", "whatsapp", "clock", "gallery", "phone", "messages", "play store", "playstore")
        if (popularApps.contains(normalized)) {
            return NovaCommand.OpenApp(normalized)
        }

        // 15. History & Help Commands
        val historyRegex = Regex("""\b(?:show\s+(?:my\s+)?(?:recent\s+)?(?:commands|history)|view\s+history|history\s+dikhao|purani\s+commands?)\b|^history$""")
        if (historyRegex.containsMatchIn(normalized)) {
            return NovaCommand.ShowHistory
        }

        val helpRegex = Regex("""\b(?:what\s+can\s+you\s+do|help\s+me|help|kya\s+kar\s+sakte\s+ho|madad\s+karo)\b|^help$""")
        if (helpRegex.containsMatchIn(normalized)) {
            return NovaCommand.ShowHelp
        }

        // 16. Battery / System Status
        if (normalized.contains("battery level") || normalized.contains("how much battery") || normalized.contains("battery kitni hai")) {
            return NovaCommand.SystemStatus("battery")
        }

        // 17. Questions / AI Queries
        val questionPrefixes = listOf("what", "who", "where", "why", "how", "tell me", "explain", "calculate", "kya", "kaun", "kahan", "kaise")
        if (questionPrefixes.any { normalized.startsWith(it) }) {
            return NovaCommand.QueryAi(rawText)
        }

        return NovaCommand.Unknown(rawText)
    }
}
