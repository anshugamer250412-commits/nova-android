package com.nova.assistant.wakeword

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.util.Log
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Owns the microphone while NOVA waits for "Hey NOVA".
 *
 * Audio: 16 kHz, mono, PCM 16-bit - identical to what the Vosk model expects.
 *
 * Microphone ownership rules (so wake-word capture and SpeechRecognizer never compete):
 *  - The AudioRecord is stopped AND released on the capture thread BEFORE [onWakeWord] / [onFailure]
 *    is invoked, so whoever reacts to the callback finds the microphone already free.
 *  - [stop] blocks (bounded) until the capture thread has released the microphone.
 *  - Exactly one of {detection, failure, stop} wins via an atomic flag; stale callbacks never fire.
 */
class WakeWordListener(
    private val engine: WakeWordEngine,
    private val onWakeWord: () -> Unit,
    private val onFailure: (String) -> Unit
) {
    private val active = AtomicBoolean(false)

    @Volatile
    private var thread: Thread? = null

    val isActive: Boolean get() = active.get()

    /** Opens the microphone and starts the capture thread. Returns failure if the mic cannot be opened. */
    @SuppressLint("MissingPermission") // RECORD_AUDIO is verified by the caller; SecurityException is handled below
    @Synchronized
    fun start(): Result<Unit> {
        if (active.get()) return Result.success(Unit)

        val minBufferBytes = AudioRecord.getMinBufferSize(SAMPLE_RATE_HZ, CHANNEL_CONFIG, AUDIO_FORMAT)
        if (minBufferBytes <= 0) {
            return Result.failure(IllegalStateException("AudioRecord.getMinBufferSize failed ($minBufferBytes)"))
        }
        val bufferBytes = maxOf(minBufferBytes, SAMPLE_RATE_HZ) // >= 0.5 s of 16-bit mono audio

        val record = try {
            AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, SAMPLE_RATE_HZ, CHANNEL_CONFIG, AUDIO_FORMAT, bufferBytes)
        } catch (e: SecurityException) {
            return Result.failure(SecurityException("Microphone permission required", e))
        } catch (e: IllegalArgumentException) {
            return Result.failure(e)
        }

        if (record.state != AudioRecord.STATE_INITIALIZED) {
            record.release()
            return Result.failure(IllegalStateException("AudioRecord failed to initialise"))
        }
        try {
            record.startRecording()
        } catch (e: IllegalStateException) {
            record.release()
            return Result.failure(e)
        }
        if (record.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
            releaseQuietly(record)
            return Result.failure(IllegalStateException("Microphone is busy or unavailable"))
        }

        active.set(true)
        engine.resetSession()
        val captureThread = Thread({ captureLoop(record) }, "nova-wakeword-capture")
        thread = captureThread
        captureThread.start()
        Log.i(TAG, "Wake-word capture started (${SAMPLE_RATE_HZ}Hz mono PCM16)")
        return Result.success(Unit)
    }

    /** Stops capturing and returns only after the microphone has been released (or the timeout hit). */
    @Synchronized
    fun stop() {
        active.set(false)
        val captureThread = thread ?: return
        thread = null
        if (captureThread !== Thread.currentThread()) {
            try {
                captureThread.join(JOIN_TIMEOUT_MS)
            } catch (e: InterruptedException) {
                Thread.currentThread().interrupt()
            }
            if (captureThread.isAlive) {
                Log.e(TAG, "Capture thread did not stop within ${JOIN_TIMEOUT_MS}ms")
            }
        }
    }

    private fun captureLoop(record: AudioRecord) {
        val frame = ShortArray(FRAME_SAMPLES)
        var detected = false
        var failure: String? = null
        try {
            while (active.get()) {
                val read = record.read(frame, 0, frame.size)
                if (read > 0) {
                    if (engine.processAudioFrame(frame, read)) {
                        detected = true
                        break
                    }
                } else if (read < 0) {
                    failure = "AudioRecord.read failed ($read)"
                    break
                }
            }
        } catch (e: Exception) {
            failure = "Wake-word capture crashed: ${e.message}"
            Log.e(TAG, failure, e)
        } finally {
            // Release the microphone BEFORE telling anyone about the outcome.
            releaseQuietly(record)
        }

        if (detected) {
            if (active.compareAndSet(true, false)) onWakeWord()
        } else if (failure != null) {
            if (active.compareAndSet(true, false)) onFailure(failure)
        }
    }

    private fun releaseQuietly(record: AudioRecord) {
        try {
            if (record.recordingState == AudioRecord.RECORDSTATE_RECORDING) record.stop()
        } catch (e: IllegalStateException) {
            Log.w(TAG, "AudioRecord.stop failed", e)
        }
        try {
            record.release()
        } catch (e: Exception) {
            Log.w(TAG, "AudioRecord.release failed", e)
        }
    }

    companion object {
        private const val TAG = "WakeWordListener"
        const val SAMPLE_RATE_HZ = VoskWakeWordEngine.SAMPLE_RATE_HZ
        private const val CHANNEL_CONFIG = AudioFormat.CHANNEL_IN_MONO
        private const val AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT

        /** 100 ms of audio per read. */
        const val FRAME_SAMPLES = SAMPLE_RATE_HZ / 10
        private const val JOIN_TIMEOUT_MS = 2000L
    }
}
