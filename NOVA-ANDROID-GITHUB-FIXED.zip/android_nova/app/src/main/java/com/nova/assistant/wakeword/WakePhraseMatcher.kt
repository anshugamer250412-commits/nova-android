package com.nova.assistant.wakeword

import org.json.JSONObject
import java.util.Locale

/** One word of a Vosk result (only present when Recognizer.setWords(true) was called). */
data class RecognizedWord(val word: String, val confidence: Float?)

/** Parsed Vosk JSON hypothesis (`getResult()` / `getFinalResult()` / `getPartialResult()`). */
data class VoskHypothesis(val text: String, val words: List<RecognizedWord>)

/**
 * Decides whether a Vosk hypothesis really contains the wake phrase.
 *
 * This works on the *recognised words* produced by the acoustic model + decoder. It never looks at
 * audio loudness / RMS: loud noise, silence or unrelated speech cannot satisfy it.
 *
 * Matching is intentionally strict: the wake phrase must appear as consecutive words
 * ("hey" immediately followed by "nova"). "nova" alone, "ok nova", "hey nora", "hey november" and
 * "hey [unk] nova" (filler between the words) are all rejected.
 */
object WakePhraseMatcher {

    const val UNKNOWN_TOKEN = "[unk]"

    /** Lower-cases and splits on whitespace. "[unk]" is kept so it separates words and breaks adjacency. */
    fun tokens(text: String): List<String> =
        text.lowercase(Locale.ROOT)
            .split(Regex("\\s+"))
            .filter { it.isNotEmpty() }

    /** Extracts the text from a Vosk partial result: `{"partial" : "hey nova"}`. */
    fun parsePartial(json: String): String =
        try {
            JSONObject(json).optString("partial", "")
        } catch (e: Exception) {
            ""
        }

    /**
     * Parses a Vosk final result, e.g.
     * `{"result":[{"conf":1.0,"end":1.2,"start":0.6,"word":"hey"}, ...],"text":"hey nova"}`.
     */
    fun parseResult(json: String): VoskHypothesis {
        val obj = try {
            JSONObject(json)
        } catch (e: Exception) {
            return VoskHypothesis("", emptyList())
        }
        val words = mutableListOf<RecognizedWord>()
        val array = obj.optJSONArray("result")
        if (array != null) {
            for (i in 0 until array.length()) {
                val w = array.optJSONObject(i) ?: continue
                val conf = if (w.has("conf")) w.optDouble("conf").toFloat() else null
                words.add(RecognizedWord(w.optString("word", "").lowercase(Locale.ROOT), conf))
            }
        }
        return VoskHypothesis(obj.optString("text", ""), words)
    }

    /** True when [phrase]'s words occur consecutively inside [text]. */
    fun containsPhrase(text: String, phrase: String): Boolean {
        val hypothesis = tokens(text)
        val target = tokens(phrase)
        if (target.isEmpty() || hypothesis.size < target.size) return false
        for (start in 0..(hypothesis.size - target.size)) {
            if (hypothesis.subList(start, start + target.size) == target) return true
        }
        return false
    }

    /**
     * Final wake decision: the text must contain the phrase AND, when Vosk supplied per-word
     * confidences, every word of the phrase must reach [minConfidence].
     */
    fun isWakeWord(hypothesis: VoskHypothesis, phrase: String, minConfidence: Float): Boolean {
        if (!containsPhrase(hypothesis.text, phrase)) return false
        val target = tokens(phrase).toSet()
        val confidences = hypothesis.words
            .filter { it.word in target }
            .mapNotNull { it.confidence }
        return confidences.all { it >= minConfidence }
    }
}
