package com.nova.assistant.ai

import com.nova.assistant.history.ConversationTurn
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

/**
 * GeminiProvider connects NOVA to Google's Gemini models
 * using lightweight native HttpURLConnection (zero external heavy libraries required).
 *
 * It parses natural language voice queries in English, Hindi, and Hinglish into
 * strictly validated JSON intent payloads, while maintaining multi-turn conversation context.
 */
class GeminiProvider(
    private var apiKey: String = "",
    private var modelName: String = "gemini-2.5-flash"
) : AiProvider {

    override val providerName: String
        get() = "Google Gemini ($modelName)"

    override val isConfigured: Boolean
        get() = apiKey.isNotBlank()

    fun updateApiKey(key: String) {
        this.apiKey = key.trim()
    }

    fun setModelName(name: String) {
        val trimmed = name.trim()
        if (trimmed.isNotEmpty()) {
            this.modelName = trimmed
        }
    }

    override suspend fun generateActionPlan(
        userPrompt: String,
        conversationHistory: List<ConversationTurn>
    ): Result<String> {
        if (!isConfigured) {
            return Result.failure(IllegalStateException("Gemini API key is not configured. Please add your key in Settings."))
        }

        return withContext(Dispatchers.IO) {
            try {
                val endpointUrl = URL("https://generativelanguage.googleapis.com/v1beta/models/$modelName:generateContent?key=$apiKey")
                val connection = endpointUrl.openConnection() as HttpURLConnection
                connection.requestMethod = "POST"
                connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                connection.doOutput = true
                connection.connectTimeout = 12000
                connection.readTimeout = 15000

                val systemInstruction = """
You are NOVA, a voice assistant running on an Android smartphone.
Your job is to understand spoken user commands in English, Hindi, or Hinglish (Hindi written in Latin script), and map them to one of the allowed Android actions.

Supported actionType values:
1. "OPEN_APP": Launch an app. Set "appName" (e.g. "youtube", "chatgpt", "whatsapp", "instagram", "camera", "spotify", "chrome", "calculator", "calendar", "clock", "maps").
2. "SEARCH_YOUTUBE": Search YouTube. Set "searchQuery" (the exact subject to search, e.g. "Minecraft Shorts", "bollywood songs").
3. "SEARCH_WEB": Google / Web search. Set "searchQuery" (e.g. "best budget gaming PC", "weather today").
4. "CALL_CONTACT": Phone call. Set "contactName" (e.g. "friend", "Rahul", "Mom", "Mummy").
5. "SEND_WHATSAPP": Send a WhatsApp message. Set "contactName" (recipient) and "messageText" (the message body to draft).
6. "TOGGLE_FLASHLIGHT": Control torch. Set "state" to true (on) or false (off).
7. "ADJUST_VOLUME": Volume control. Set "volumeDirection" to "up", "down", or "mute".
8. "OPEN_SETTINGS": Open settings. Set "settingTarget" to "wifi", "bluetooth", "display", "sound", "battery", "apps", "accessibility", or "general".
9. "GET_BATTERY_STATUS": Check battery level.
10. "CONVERSE": For general knowledge questions, follow-up answers, explanations, or greetings. Provide the spoken answer directly in "speechResponse".

Formatting Rules:
- Return ONLY a valid single JSON object. No markdown backticks, no code fence, no extra text.
- "speechResponse" must ALWAYS be provided: a natural, concise sentence in the same language/dialect the user spoke explaining what is happening or directly answering their question.

Examples:
- User: "YouTube kholo"
  {"actionType":"OPEN_APP","appName":"youtube","speechResponse":"YouTube khol raha hoon."}
- User: "YouTube par Minecraft Shorts search karo"
  {"actionType":"SEARCH_YOUTUBE","searchQuery":"Minecraft Shorts","speechResponse":"YouTube par Minecraft Shorts search kar raha hoon."}
- User: "Open ChatGPT"
  {"actionType":"OPEN_APP","appName":"chatgpt","speechResponse":"Opening ChatGPT."}
- User: "Google par search karo, best budget gaming PC"
  {"actionType":"SEARCH_WEB","searchQuery":"best budget gaming PC","speechResponse":"Google par best budget gaming PC dhoondh raha hoon."}
- User: "Mere dost ko WhatsApp par message bhejna hai"
  {"actionType":"SEND_WHATSAPP","contactName":"dost","messageText":"","speechResponse":"WhatsApp khol raha hoon, kripya message compose karein."}
- User: "Call Mom"
  {"actionType":"CALL_CONTACT","contactName":"Mom","speechResponse":"Opening phone dialer to call Mom."}
- User: "Torch on karo"
  {"actionType":"TOGGLE_FLASHLIGHT","state":true,"speechResponse":"Flashlight on kar di hai."}
- User: "Who was the first person on the moon?"
  {"actionType":"CONVERSE","speechResponse":"Neil Armstrong was the first person to walk on the moon in 1969."}
                """.trimIndent()

                val contentsArray = JSONArray()

                // Add recent conversation context for follow-up questions
                for (turn in conversationHistory) {
                    if (turn.user.isNotBlank()) {
                        contentsArray.put(JSONObject().apply {
                            put("role", "user")
                            put("parts", JSONArray().apply { put(JSONObject().put("text", turn.user)) })
                        })
                    }
                    if (turn.assistant.isNotBlank()) {
                        contentsArray.put(JSONObject().apply {
                            put("role", "model")
                            put("parts", JSONArray().apply { put(JSONObject().put("text", turn.assistant)) })
                        })
                    }
                }

                // Append the current turn with system instructions
                contentsArray.put(JSONObject().apply {
                    put("role", "user")
                    put("parts", JSONArray().apply {
                        put(JSONObject().put("text", "$systemInstruction\n\nUser command: \"$userPrompt\""))
                    })
                })

                val requestJson = JSONObject().apply {
                    put("contents", contentsArray)
                    put("generationConfig", JSONObject().apply {
                        put("temperature", 0.2)
                        put("maxOutputTokens", 500)
                    })
                }

                OutputStreamWriter(connection.outputStream, Charsets.UTF_8).use { writer ->
                    writer.write(requestJson.toString())
                    writer.flush()
                }

                val responseCode = connection.responseCode
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    val responseText = BufferedReader(InputStreamReader(connection.inputStream, Charsets.UTF_8)).use { it.readText() }
                    val jsonResponse = JSONObject(responseText)
                    val candidates = jsonResponse.optJSONArray("candidates")
                    val content = candidates?.optJSONObject(0)?.optJSONObject("content")
                    val parts = content?.optJSONArray("parts")
                    val rawGenerated = parts?.optJSONObject(0)?.optString("text") ?: ""

                    // Sanitize any accidental markdown code fences
                    val cleanedJson = rawGenerated.trim()
                        .removePrefix("```json")
                        .removePrefix("```")
                        .removeSuffix("```")
                        .trim()

                    Result.success(cleanedJson)
                } else {
                    val errorStream = connection.errorStream ?: connection.inputStream
                    val errorText = BufferedReader(InputStreamReader(errorStream, Charsets.UTF_8)).use { it.readText() }
                    val message = when (responseCode) {
                        400 -> "Invalid request to Gemini API (HTTP 400)."
                        403 -> "Invalid or restricted Gemini API key. Please check your key at aistudio.google.com."
                        404 -> "Model $modelName not found on API endpoint (HTTP 404)."
                        429 -> "Gemini API rate limit reached. Please wait a few moments and try again."
                        500, 503 -> "Gemini service temporarily unavailable (HTTP $responseCode)."
                        else -> "Gemini API error (HTTP $responseCode): $errorText"
                    }
                    Result.failure(RuntimeException(message))
                }
            } catch (e: java.net.SocketTimeoutException) {
                Result.failure(RuntimeException("Gemini network request timed out. Please check your internet connection."))
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }
}
