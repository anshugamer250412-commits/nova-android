package com.nova.assistant.actions

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.MediaStore
import android.util.Log
import java.net.URLEncoder

class AppLauncher(private val context: Context) {

    private val tag = "AppLauncher"

    // Mapping of friendly names and aliases to well-known package names or system intents
    private val knownAppPackages = mapOf(
        "youtube" to listOf("com.google.android.youtube"),
        "chrome" to listOf("com.android.chrome", "org.chromium.chrome"),
        "maps" to listOf("com.google.android.apps.maps"),
        "whatsapp" to listOf("com.whatsapp"),
        "spotify" to listOf("com.spotify.music"),
        "play store" to listOf("com.android.vending"),
        "playstore" to listOf("com.android.vending"),
        "google play" to listOf("com.android.vending"),
        "google play store" to listOf("com.android.vending"),
        "calculator" to listOf(
            "com.google.android.calculator",
            "com.android.calculator2",
            "com.sec.android.app.popupcalculator"
        ),
        "calendar" to listOf(
            "com.google.android.calendar",
            "com.android.calendar",
            "com.samsung.android.calendar"
        ),
        "clock" to listOf(
            "com.google.android.deskclock",
            "com.android.deskclock",
            "com.sec.android.app.clockpackage"
        ),
        "camera" to listOf(
            "com.google.android.GoogleCamera",
            "com.android.camera",
            "com.sec.android.app.camera"
        ),
        "photos" to listOf(
            "com.google.android.apps.photos",
            "com.android.gallery3d",
            "com.sec.android.gallery3d"
        ),
        "gallery" to listOf(
            "com.google.android.apps.photos",
            "com.android.gallery3d",
            "com.sec.android.gallery3d"
        ),
        "gmail" to listOf("com.google.android.gm"),
        "settings" to listOf("com.android.settings")
    )

    fun launchApp(appNameQuery: String): Result<String> {
        val query = appNameQuery.trim().lowercase()
        val pm = context.packageManager

        // Special handling for Play Store queries
        if (query == "play store" || query == "playstore" || query == "google play" || query == "google play store") {
            return openPlayStore("")
        }

        // Special handling for Camera (can also use ACTION_IMAGE_CAPTURE)
        if (query == "camera") {
            try {
                val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                if (intent.resolveActivity(pm) != null) {
                    context.startActivity(intent)
                    return Result.success("Camera opened")
                }
            } catch (e: Exception) {
                Log.w(tag, "Camera intent fallback error: ${e.message}")
            }
        }

        // 1. Check known packages
        val candidates = knownAppPackages[query]
        if (candidates != null) {
            for (pkg in candidates) {
                val launchIntent = pm.getLaunchIntentForPackage(pkg)
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(launchIntent)
                    return Result.success("Launched $query")
                }
            }
        }

        // 2. Dynamic search across all installed launcher applications
        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolveInfoList = pm.queryIntentActivities(mainIntent, PackageManager.MATCH_DEFAULT_ONLY)

        for (info in resolveInfoList) {
            val label = info.loadLabel(pm).toString().lowercase()
            val packageName = info.activityInfo.packageName.lowercase()

            if (label == query || label.contains(query) || packageName.contains(query)) {
                val launchIntent = pm.getLaunchIntentForPackage(info.activityInfo.packageName)
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(launchIntent)
                    return Result.success("Launched ${info.loadLabel(pm)}")
                }
            }
        }

        return Result.failure(
            NoSuchElementException("Could not find installed application matching '$appNameQuery'. Please check if the app is installed.")
        )
    }

    /**
     * Opens Google Play Store to search for an app or open Play Store home.
     * Uses market:// URI with web fallback.
     */
    fun openPlayStore(searchQuery: String): Result<String> {
        return try {
            val trimmed = searchQuery.trim()
            val intent = if (trimmed.isNotEmpty()) {
                val encoded = URLEncoder.encode(trimmed, "UTF-8")
                Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=$encoded")).apply {
                    setPackage("com.android.vending")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            } else {
                context.packageManager.getLaunchIntentForPackage("com.android.vending")?.apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                } ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            }

            if (intent.resolveActivity(context.packageManager) != null) {
                context.startActivity(intent)
                val msg = if (trimmed.isNotEmpty()) "Searching Play Store for $trimmed" else "Opening Google Play Store"
                Result.success(msg)
            } else {
                // Web fallback
                val encoded = if (trimmed.isNotEmpty()) URLEncoder.encode(trimmed, "UTF-8") else ""
                val webUrl = if (encoded.isNotEmpty()) "https://play.google.com/store/search?q=$encoded" else "https://play.google.com/store"
                val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(webUrl)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(browserIntent)
                val msg = if (trimmed.isNotEmpty()) "Opened Play Store web search for $trimmed" else "Opened Play Store web"
                Result.success(msg)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
