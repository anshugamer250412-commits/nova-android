package com.nova.assistant.ui.theme

import androidx.compose.ui.graphics.Color

val NovaDeepNavy = Color(0xFF090D16)
val NovaSurfaceDark = Color(0xFF111827)
val NovaSurfaceLight = Color(0xFF1F2937)
val NovaCyan = Color(0xFF06B6D4)
val NovaNeonBlue = Color(0xFF38BDF8)
val NovaPurple = Color(0xFF8B5CF6)
val NovaSuccessGreen = Color(0xFF10B981)
val NovaErrorRed = Color(0xFFEF4444)
val NovaTextPrimary = Color(0xFFF8FAFC)
val NovaTextSecondary = Color(0xFF94A3B8)
val NovaBorder = Color(0xFF374151)
