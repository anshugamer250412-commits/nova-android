package com.nova.assistant.actions

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import androidx.core.content.ContextCompat

class ContactCaller(private val context: Context) {

    data class MatchedContact(val name: String, val number: String)

    fun prepareCall(contactNameQuery: String): Result<Pair<String, String>> {
        val trimmedQuery = contactNameQuery.trim()
        val hasPermission = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.READ_CONTACTS
        ) == PackageManager.PERMISSION_GRANTED

        // If no contact permission granted yet, return fallback dialer instruction
        if (!hasPermission) {
            val dialIntent = Intent(Intent.ACTION_DIAL).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(dialIntent)
            return Result.success(
                Pair(
                    "Contacts permission is required to search contacts. Opening phone dialer.",
                    "Grant contacts permission in Settings to look up '$trimmedQuery' automatically."
                )
            )
        }

        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )
        val selection = "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?"
        val selectionArgs = arrayOf("%$trimmedQuery%")

        try {
            val matches = mutableListOf<MatchedContact>()
            val cursor = context.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                projection,
                selection,
                selectionArgs,
                null
            )

            cursor?.use {
                val nameIndex = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val numberIndex = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)

                while (it.moveToNext() && matches.size < 5) {
                    val name = it.getString(nameIndex) ?: ""
                    val number = it.getString(numberIndex) ?: ""
                    if (name.isNotBlank() && number.isNotBlank()) {
                        matches.add(MatchedContact(name, number))
                    }
                }
            }

            if (matches.isNotEmpty()) {
                // Check if there is an exact case-insensitive match
                val exactMatch = matches.firstOrNull { it.name.equals(trimmedQuery, ignoreCase = true) }
                val targetContact = exactMatch ?: matches.first()

                // Safe confirmation flow: Open phone dialer with number pre-filled
                // Least-privileged supported intent (ACTION_DIAL requires user tap to confirm call)
                val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${targetContact.number}")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(dialIntent)

                val speech = if (matches.size == 1) {
                    "Found ${targetContact.name}. Opening dialer to confirm call."
                } else if (exactMatch != null) {
                    "Found exact match for ${exactMatch.name}. Opening dialer."
                } else {
                    val names = matches.take(2).joinToString(" and ") { it.name }
                    "Multiple contacts found: $names. Opening dialer for ${targetContact.name}."
                }

                val detail = if (matches.size == 1) {
                    "Ready to dial: ${targetContact.name} (${targetContact.number})"
                } else {
                    "Matched: " + matches.joinToString(", ") { "${it.name} (${it.number})" }
                }

                return Result.success(Pair(speech, detail))
            }
        } catch (e: Exception) {
            return Result.failure(e)
        }

        // Fallback: contact not found in phonebook, open dialer
        val dialIntent = Intent(Intent.ACTION_DIAL).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(dialIntent)
        return Result.success(
            Pair(
                "Could not find '$trimmedQuery' in your contacts. Opening phone dialer.",
                "No contact match for: $trimmedQuery"
            )
        )
    }
}
