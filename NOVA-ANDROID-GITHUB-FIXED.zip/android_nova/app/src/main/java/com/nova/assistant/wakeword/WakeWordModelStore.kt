package com.nova.assistant.wakeword

import android.content.Context
import android.content.res.AssetManager
import androidx.core.content.pm.PackageInfoCompat
import java.io.File
import java.io.FileNotFoundException
import java.io.IOException

/**
 * Locates, installs and validates the offline Vosk model used for "Hey NOVA".
 *
 * Vosk's native `Model` needs a real filesystem path, so the model bundled in `assets/model-en-us/`
 * (placed there by the `fetchVoskModel` Gradle task) is copied once into app-private storage.
 * The copy is repeated after every app install/update.
 *
 * Validation is structural AND lexical: besides the acoustic/graph files it checks that the model's
 * own word list (`graph/words.txt`) contains every word of the wake phrase. A model whose vocabulary
 * lacks "nova" can never recognise "Hey NOVA", so it is rejected here with a clear error instead of
 * silently never triggering.
 */
object WakeWordModelStore {

    const val DEFAULT_MODEL_ASSET_DIR = "model-en-us"
    private const val INSTALL_ROOT = "vosk-models"
    private const val MARKER_FILE = ".nova_install_marker"

    /**
     * Files of a small Vosk model with a dynamic graph (HCLr.fst + Gr.fst). That graph type is what
     * allows `Recognizer(model, rate, grammar)` - the restricted-phrase mode used for wake-word spotting.
     */
    val REQUIRED_FILES = listOf(
        "am/final.mdl",
        "conf/mfcc.conf",
        "graph/HCLr.fst",
        "graph/Gr.fst",
        "graph/words.txt"
    )

    val REQUIRED_VOCABULARY = listOf("hey", "nova")

    /** Cheap check (no copying): is a model folder bundled in the APK assets? Safe on the main thread. */
    fun isBundled(context: Context, assetDir: String = DEFAULT_MODEL_ASSET_DIR): Boolean =
        try {
            val top = context.assets.list(assetDir)?.toSet() ?: emptySet()
            "am" in top && "conf" in top && "graph" in top
        } catch (e: IOException) {
            false
        }

    /**
     * Ensures an up-to-date, valid model copy exists in private storage and returns its directory.
     * Blocking disk I/O - call from a background thread.
     */
    fun install(context: Context, assetDir: String = DEFAULT_MODEL_ASSET_DIR): Result<File> {
        return try {
            val root = File(context.filesDir, INSTALL_ROOT).apply { mkdirs() }
            val target = File(root, assetDir)
            val versionTag = installVersionTag(context)
            val marker = File(target, MARKER_FILE)

            val upToDate = marker.isFile && marker.readText() == versionTag && validate(target).isSuccess
            if (!upToDate) {
                if (!isBundled(context, assetDir)) {
                    return Result.failure(
                        FileNotFoundException(
                            "Wake-word model not found in app assets ('assets/$assetDir'). " +
                                "Build with network access so 'fetchVoskModel' can download " +
                                "vosk-model-small-en-us-0.15, or unzip it into app/src/main/assets/$assetDir/."
                        )
                    )
                }
                val staging = File(root, "$assetDir.staging")
                staging.deleteRecursively()
                copyAssetTree(context.assets, assetDir, staging)
                File(staging, MARKER_FILE).writeText(versionTag)
                target.deleteRecursively()
                if (!staging.renameTo(target)) {
                    throw IOException("Could not move installed model into place: ${target.absolutePath}")
                }
            }
            validate(target).map { target }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /** Structural + vocabulary validation of an installed model directory. Pure file I/O. */
    fun validate(modelDir: File, requiredWords: List<String> = REQUIRED_VOCABULARY): Result<Unit> {
        if (!modelDir.isDirectory) {
            return Result.failure(FileNotFoundException("Model directory does not exist: ${modelDir.absolutePath}"))
        }
        for (relative in REQUIRED_FILES) {
            val file = File(modelDir, relative)
            if (!file.isFile || file.length() == 0L) {
                return Result.failure(
                    WakeWordModelException(
                        "Model is incomplete: '$relative' is missing or empty. " +
                            "A small Vosk model with a dynamic graph (HCLr.fst/Gr.fst) is required for phrase spotting."
                    )
                )
            }
        }
        val vocabulary = readVocabulary(File(modelDir, "graph/words.txt"), requiredWords.map { it.lowercase() }.toSet())
        val missing = requiredWords.filter { it.lowercase() !in vocabulary }
        if (missing.isNotEmpty()) {
            return Result.failure(
                WakeWordModelException("Model vocabulary does not contain: ${missing.joinToString()} - it cannot recognise the wake phrase.")
            )
        }
        return Result.success(Unit)
    }

    /** Returns the subset of [wanted] that occurs as a word in a Kaldi `words.txt` ("word id" per line). */
    private fun readVocabulary(wordsFile: File, wanted: Set<String>): Set<String> {
        val found = mutableSetOf<String>()
        wordsFile.bufferedReader().useLines { lines ->
            for (line in lines) {
                val word = line.substringBefore(' ').lowercase()
                if (word in wanted) {
                    found.add(word)
                    if (found.size == wanted.size) break
                }
            }
        }
        return found
    }

    private fun installVersionTag(context: Context): String {
        val info = context.packageManager.getPackageInfo(context.packageName, 0)
        return "${PackageInfoCompat.getLongVersionCode(info)}-${info.lastUpdateTime}"
    }

    private fun copyAssetTree(assets: AssetManager, assetPath: String, destination: File) {
        val children = assets.list(assetPath) ?: emptyArray()
        if (children.isEmpty()) {
            destination.parentFile?.mkdirs()
            assets.open(assetPath).use { input ->
                destination.outputStream().use { output -> input.copyTo(output) }
            }
        } else {
            destination.mkdirs()
            for (child in children) {
                copyAssetTree(assets, "$assetPath/$child", File(destination, child))
            }
        }
    }
}
