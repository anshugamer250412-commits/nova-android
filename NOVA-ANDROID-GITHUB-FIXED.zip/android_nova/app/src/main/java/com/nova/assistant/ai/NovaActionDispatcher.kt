package com.nova.assistant.ai

import com.nova.assistant.parser.NovaCommand
import com.nova.assistant.parser.SearchPlatform
import com.nova.assistant.parser.SettingTarget
import com.nova.assistant.parser.VolumeDirection
import org.json.JSONObject

/**
 * NovaActionDispatcher enforces a STRICT SECURITY ALLOWLIST on all AI outputs.
 * It prevents execution of arbitrary code, shell commands, or unapproved actions,
 * and maps valid structured JSON into strongly typed NovaCommand instances.
 */
class NovaActionDispatcher {

    private val allowedActions = setOf(
        "OPEN_APP",
        "SEARCH_WEB",
        "SEARCH_YOUTUBE",
        "CALL_CONTACT",
        "SEND_WHATSAPP",
        "TOGGLE_FLASHLIGHT",
        "ADJUST_VOLUME",
        "OPEN_SETTINGS",
        "GET_BATTERY_STATUS",
        "CONVERSE"
    )

    fun validateAndMap(requestJson: String): Result<NovaCommand> {
        val trimmed = requestJson.trim()
        if (!trimmed.startsWith("{") || !trimmed.endsWith("}")) {
            return Result.failure(IllegalArgumentException("Malformed AI response: must be a JSON object"))
        }

        return try {
            var action = ""
            var appName = ""
            var query = ""
            var contact = ""
            var message = ""
            var hasState = false
            var stateValue = false
            var volumeDir = ""
            var settingTarget = ""
            var speechResponse = ""

            // Primary: Standard org.json.JSONObject parsing
            var jsonParsedSuccessfully = false
            try {
                val json = JSONObject(trimmed)
                action = json.optString("actionType", "").trim().uppercase()
                appName = json.optString("appName", json.optString("appQuery", "")).trim()
                query = json.optString("searchQuery", json.optString("query", "")).trim()
                contact = json.optString("contactName", json.optString("recipient", "")).trim()
                message = json.optString("messageText", json.optString("message", "")).trim()
                if (json.has("state")) {
                    hasState = true
                    stateValue = json.optBoolean("state")
                }
                volumeDir = json.optString("volumeDirection", json.optString("direction", "")).trim()
                settingTarget = json.optString("settingTarget", json.optString("target", "")).trim()
                speechResponse = json.optString("speechResponse", "").trim()
                if (action.isNotEmpty()) {
                    jsonParsedSuccessfully = true
                }
            } catch (e: Exception) {
                // Falls back to resilient extractor below if unmocked JVM or stub
            }

            // Resilient fallback for JVM test environments without active JSON mock
            if (!jsonParsedSuccessfully) {
                val actionMatch = Regex(""""actionType"\s*:\s*"([^"]+)"""", RegexOption.IGNORE_CASE).find(trimmed)
                action = actionMatch?.groupValues?.get(1)?.trim()?.uppercase() ?: "CONVERSE"
                if (appName.isEmpty()) {
                    appName = Regex(""""(?:appName|appQuery)"\s*:\s*"([^"]+)"""", RegexOption.IGNORE_CASE).find(trimmed)?.groupValues?.get(1)?.trim() ?: ""
                }
                if (query.isEmpty()) {
                    query = Regex(""""(?:searchQuery|query)"\s*:\s*"([^"]+)"""", RegexOption.IGNORE_CASE).find(trimmed)?.groupValues?.get(1)?.trim() ?: ""
                }
                if (contact.isEmpty()) {
                    contact = Regex(""""(?:contactName|recipient)"\s*:\s*"([^"]+)"""", RegexOption.IGNORE_CASE).find(trimmed)?.groupValues?.get(1)?.trim() ?: ""
                }
                if (message.isEmpty()) {
                    message = Regex(""""(?:messageText|message)"\s*:\s*"([^"]+)"""", RegexOption.IGNORE_CASE).find(trimmed)?.groupValues?.get(1)?.trim() ?: ""
                }
                if (!hasState) {
                    val stateMatch = Regex(""""state"\s*:\s*(true|false)""", RegexOption.IGNORE_CASE).find(trimmed)
                    if (stateMatch != null) {
                        hasState = true
                        stateValue = stateMatch.groupValues[1].toBoolean()
                    }
                }
                if (volumeDir.isEmpty()) {
                    volumeDir = Regex(""""(?:volumeDirection|direction)"\s*:\s*"([^"]+)"""", RegexOption.IGNORE_CASE).find(trimmed)?.groupValues?.get(1)?.trim() ?: ""
                }
                if (settingTarget.isEmpty()) {
                    settingTarget = Regex(""""(?:settingTarget|target)"\s*:\s*"([^"]+)"""", RegexOption.IGNORE_CASE).find(trimmed)?.groupValues?.get(1)?.trim() ?: ""
                }
                if (speechResponse.isEmpty()) {
                    speechResponse = Regex(""""speechResponse"\s*:\s*"([^"]+)"""", RegexOption.IGNORE_CASE).find(trimmed)?.groupValues?.get(1)?.trim() ?: "I am NOVA, your voice assistant."
                }
            }

            if (!allowedActions.contains(action)) {
                return Result.failure(
                    SecurityException("Blocked unauthorized AI action '$action'. Only allowlisted phone actions are permitted.")
                )
            }

            val command = when (action) {
                "OPEN_APP" -> {
                    if (appName.isEmpty()) {
                        return Result.failure(IllegalArgumentException("Missing appName for OPEN_APP"))
                    }
                    NovaCommand.OpenApp(appName)
                }

                "SEARCH_WEB" -> {
                    if (query.isEmpty()) {
                        return Result.failure(IllegalArgumentException("Missing searchQuery for SEARCH_WEB"))
                    }
                    NovaCommand.WebSearch(query, SearchPlatform.GOOGLE)
                }

                "SEARCH_YOUTUBE" -> {
                    if (query.isEmpty()) {
                        return Result.failure(IllegalArgumentException("Missing searchQuery for SEARCH_YOUTUBE"))
                    }
                    NovaCommand.WebSearch(query, SearchPlatform.YOUTUBE)
                }

                "CALL_CONTACT" -> {
                    val finalContact = if (contact.isNotEmpty()) contact else "someone"
                    NovaCommand.CallContact(finalContact)
                }

                "SEND_WHATSAPP" -> {
                    val finalRecipient = if (contact.isNotEmpty()) contact else "someone"
                    NovaCommand.SendWhatsAppMessage(finalRecipient, message)
                }

                "TOGGLE_FLASHLIGHT" -> {
                    val desired = if (hasState) stateValue else null
                    NovaCommand.ToggleFlashlight(desired)
                }

                "ADJUST_VOLUME" -> {
                    val dir = when (volumeDir.lowercase()) {
                        "down", "kam", "ghatao", "low" -> VolumeDirection.DOWN
                        "mute", "silent", "chup" -> VolumeDirection.MUTE
                        else -> VolumeDirection.UP
                    }
                    NovaCommand.AdjustVolume(dir)
                }

                "OPEN_SETTINGS" -> {
                    val target = when (settingTarget.lowercase()) {
                        "wifi", "wi-fi", "internet" -> SettingTarget.Wifi
                        "bluetooth", "bt" -> SettingTarget.Bluetooth
                        "display", "screen", "brightness" -> SettingTarget.Display
                        "sound", "volume", "audio" -> SettingTarget.Sound
                        "battery", "power" -> SettingTarget.Battery
                        "apps", "applications" -> SettingTarget.Apps
                        "accessibility" -> SettingTarget.Accessibility
                        "location", "gps" -> SettingTarget.Location
                        else -> SettingTarget.General
                    }
                    NovaCommand.OpenSettings(target)
                }

                "GET_BATTERY_STATUS" -> NovaCommand.SystemStatus("battery")

                "CONVERSE" -> {
                    val speech = if (speechResponse.isNotEmpty()) speechResponse else "I am NOVA, your voice assistant."
                    NovaCommand.QueryAi(speech)
                }

                else -> NovaCommand.Unknown(requestJson)
            }

            Result.success(command)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
