package com.nova.assistant.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import androidx.core.app.NotificationCompat
import com.nova.assistant.MainActivity
import com.nova.assistant.NovaApplication
import com.nova.assistant.R
import com.nova.assistant.parser.CommandResult
import com.nova.assistant.parser.NovaCommand
import com.nova.assistant.wakeword.WakeWordEngine
import com.nova.assistant.wakeword.WakeWordListener
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

enum class AssistantPhase {
    STOPPED,
    STARTING,
    IDLE,
    WAKE_WORD_LISTENING,
    COMMAND_LISTENING,
    LISTENING,
    PROCESSING,
    SPEAKING,
    EXECUTING_ACTION,
    ERROR
}

/**
 * NovaVoiceService is the central Android Foreground Service:
 * - Single source of truth for voice assistant lifecycle
 * - Enforces single microphone session (no AudioRecord / SpeechRecognizer contention):
 *     "Hey NOVA" is detected offline by Vosk on a dedicated AudioRecord (WakeWordListener); that
 *     AudioRecord is stopped + released BEFORE the SpeechRecognizer command session opens, and
 *     wake-word capture only resumes after the command interaction has finished.
 * - State machine lifecycle: STOPPED -> STARTING -> WAKE_WORD_LISTENING -> COMMAND_LISTENING -> PROCESSING -> SPEAKING -> WAKE_WORD_LISTENING
 * - Connects natural Hindi, Hinglish, and English queries to Gemini AI with conversation history
 * - Speaks natural TTS response and prevents self-echo recognition
 * - Exposes real-time StateFlows so the UI accurately reflects true service state
 */
class NovaVoiceService : Service(), RecognitionListener {

    private val tag = "NovaVoiceService"
    private val channelId = "nova_voice_service_channel"
    private val notificationId = 1002
    private val mainHandler = Handler(Looper.getMainLooper())
    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private var speechRecognizer: SpeechRecognizer? = null
    private var isRecognizerActive = false
    private var isServiceActive = false

    // Wake-word (Vosk) capture state. The listener owns the microphone only while WAKE_WORD_LISTENING.
    private var wakeListener: WakeWordListener? = null
    private var wakeCaptureId = 0L          // invalidates callbacks from stopped/stale captures
    private var wakeEngineLoading = false
    private var wakeCaptureFailures = 0
    private var wakeAckToken = 0L

    private val stateMachine = AssistantStateMachine()
    private var currentSessionId: Long = 0L

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        when (action) {
            ACTION_STOP -> {
                stopAssistant()
                return START_NOT_STICKY
            }
            ACTION_LISTEN -> {
                // Explicit push-to-talk trigger
                if (!isServiceActive) {
                    startForegroundServiceInternal()
                }
                startCommandListening()
                return START_STICKY
            }
            ACTION_STOP_SPEAKING -> {
                stopSpeaking()
                return START_STICKY
            }
        }

        startForegroundServiceInternal()
        return START_STICKY
    }

    private fun startForegroundServiceInternal() {
        isServiceActive = true
        isRunning = true
        wakeCaptureFailures = 0
        currentSessionId = stateMachine.startNewSession()

        _serviceState.value = AssistantPhase.STARTING
        _statusMessage.value = "Starting NOVA assistant..."
        val notification = buildNotification("NOVA Assistant", "Starting voice service...")

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                // Android 11+ only lets a foreground service keep using the microphone in the
                // background when it is started with the microphone type (not NONE).
                val serviceType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                } else {
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_NONE
                }
                startForeground(notificationId, notification, serviceType)
            } else {
                startForeground(notificationId, notification)
            }

            evaluateListeningMode()
        } catch (e: Exception) {
            Log.e(tag, "Failed starting foreground service: ${e.message}")
            stateMachine.transitionTo(AssistantPhase.ERROR)
            _serviceState.value = AssistantPhase.ERROR
            _statusMessage.value = "Failed to start service: ${e.message}"
            stopSelf()
        }
    }

    private fun evaluateListeningMode() {
        val app = NovaApplication.instance
        val mode = app.getListeningMode()

        if (mode == "CONTINUOUS_WAKE_WORD" || mode == "CONTINUOUS") {
            startWakeWordListening()
        } else {
            // Push-to-Talk mode: stand by ready for button tap or notification action
            stateMachine.transitionTo(AssistantPhase.WAKE_WORD_LISTENING)
            _serviceState.value = AssistantPhase.IDLE
            _statusMessage.value = "Ready • Tap Speak or say 'Hey NOVA'"
            updateNotification("NOVA is Ready", "Tap Speak or say 'Hey NOVA'")
            // Keep background wake-word monitor active
            startWakeWordListening()
        }
    }

    /**
     * Starts continuous, offline listening for the wake phrase "Hey NOVA" (Vosk on a dedicated
     * AudioRecord). Ordinary speech / noise never leaves this state: only a genuine phrase match does.
     * Idempotent: any previous capture or recognizer is torn down first so only one thing owns the mic.
     */
    fun startWakeWordListening() {
        if (!isServiceActive) return

        stopWakeWordCapture()
        destroyRecognizer()
        NovaApplication.instance.tts.stop()

        val app = NovaApplication.instance
        if (!app.permissionManager.hasRecordAudioPermission()) {
            stateMachine.handleRecognitionError(isFatalPermission = true)
            _serviceState.value = AssistantPhase.ERROR
            _statusMessage.value = "Microphone permission required"
            updateNotification("NOVA Permission Needed", "Grant microphone permission in app settings")
            return
        }

        val engine = app.wakeWordEngine
        if (!engine.isReady) {
            loadWakeWordEngineAsync()
            return
        }
        beginWakeWordCapture(engine)
    }

    /** Loads the Vosk model off the main thread, then starts wake-word capture. */
    private fun loadWakeWordEngineAsync() {
        if (wakeEngineLoading) return
        wakeEngineLoading = true
        _serviceState.value = AssistantPhase.STARTING
        _statusMessage.value = "Loading offline wake-word model..."
        updateNotification("NOVA", "Loading wake-word model...")

        val app = NovaApplication.instance
        serviceScope.launch {
            val result = withContext(Dispatchers.Default) { app.wakeWordEngine.initialize(app) }
            wakeEngineLoading = false
            if (!isServiceActive) {
                app.wakeWordEngine.release()
                return@launch
            }
            // Only continue if nothing else (e.g. push-to-talk) took over while the model was loading.
            if (_serviceState.value != AssistantPhase.STARTING) return@launch
            result.fold(
                onSuccess = { startWakeWordListening() },
                onFailure = { onWakeWordUnavailable(it.message ?: "unknown error") }
            )
        }
    }

    private fun beginWakeWordCapture(engine: WakeWordEngine) {
        val captureId = ++wakeCaptureId
        val listener = WakeWordListener(
            engine = engine,
            onWakeWord = { mainHandler.post { onWakeWordDetected(captureId) } },
            onFailure = { reason -> mainHandler.post { onWakeWordCaptureFailed(captureId, reason) } }
        )
        val started = listener.start()
        if (started.isFailure) {
            onWakeWordCaptureFailed(captureId, started.exceptionOrNull()?.message ?: "Microphone unavailable")
            return
        }
        wakeListener = listener

        stateMachine.transitionTo(AssistantPhase.WAKE_WORD_LISTENING)
        _serviceState.value = AssistantPhase.WAKE_WORD_LISTENING
        _statusMessage.value = "Listening for \"Hey NOVA\"..."
        updateNotification("NOVA is Active", "Listening for \"Hey NOVA\"...")
    }

    /** Stops wake-word capture and returns only after the microphone has been released. */
    private fun stopWakeWordCapture() {
        wakeCaptureId++ // any callback from the old capture is now stale
        wakeListener?.stop()
        wakeListener = null
    }

    /**
     * A genuine "Hey NOVA" was recognised. The wake-word AudioRecord is already released, so we
     * acknowledge (existing "Yes?" prompt) and then open the existing command-listening session.
     */
    private fun onWakeWordDetected(captureId: Long) {
        if (!isServiceActive || captureId != wakeCaptureId) return // stale: push-to-talk / restart / stop won

        wakeCaptureFailures = 0
        stopWakeWordCapture() // idempotent; guarantees the mic is free before SpeechRecognizer opens
        Log.i(tag, "Wake phrase \"Hey NOVA\" recognised -> entering command listening")

        stateMachine.transitionTo(AssistantPhase.SPEAKING)
        _serviceState.value = AssistantPhase.SPEAKING
        _statusMessage.value = "Yes? I'm listening."
        updateNotification("NOVA", "Yes? I'm listening.")

        val token = ++wakeAckToken
        val openCommandSession = Runnable {
            if (isServiceActive && token == wakeAckToken && _serviceState.value == AssistantPhase.SPEAKING) {
                startCommandListening()
            }
        }
        NovaApplication.instance.tts.speak("Yes?") {
            mainHandler.postDelayed(openCommandSession, 250)
        }
        // Watchdog: if TTS never reports completion, still open the command session.
        mainHandler.postDelayed(openCommandSession, WAKE_ACK_WATCHDOG_MS)
    }

    private fun onWakeWordCaptureFailed(captureId: Long, reason: String) {
        if (!isServiceActive || captureId != wakeCaptureId) return
        stopWakeWordCapture()
        wakeCaptureFailures++
        Log.w(tag, "Wake-word capture failure #$wakeCaptureFailures: $reason")

        if (wakeCaptureFailures <= MAX_WAKE_CAPTURE_RETRIES) {
            resetToWakeWordListening(500)
        } else {
            stateMachine.transitionTo(AssistantPhase.ERROR)
            _serviceState.value = AssistantPhase.ERROR
            _statusMessage.value = "Wake-word microphone error: $reason. Tap Speak to retry."
            updateNotification("NOVA Microphone Error", reason)
        }
    }

    /** Model missing / failed to load: say so honestly and leave push-to-talk usable. */
    private fun onWakeWordUnavailable(reason: String) {
        Log.e(tag, "Wake-word engine unavailable: $reason")
        _serviceState.value = AssistantPhase.IDLE
        _statusMessage.value = "\"Hey NOVA\" unavailable - tap Speak instead. ($reason)"
        updateNotification("NOVA is Ready (tap Speak)", "Wake word unavailable: $reason")
    }

    private fun releaseWakeWordEngine() {
        val engine = NovaApplication.instance.wakeWordEngine
        if (wakeEngineLoading) {
            // initialize() holds the engine lock; wait for it off the main thread.
            Thread({ engine.release() }, "nova-wakeword-release").start()
        } else {
            engine.release()
        }
    }

    /**
     * Starts listening for user's actual command after wake word detected or on explicit tap.
     */
    fun startCommandListening() {
        if (!isServiceActive) return

        // Single microphone owner: wake-word capture must be fully released before SpeechRecognizer opens.
        stopWakeWordCapture()
        wakeCaptureFailures = 0
        destroyRecognizer()
        NovaApplication.instance.tts.stop()

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            stateMachine.transitionTo(AssistantPhase.ERROR)
            _serviceState.value = AssistantPhase.ERROR
            _statusMessage.value = "Speech recognition is not available on this device"
            return
        }

        try {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
                setRecognitionListener(this@NovaVoiceService)
            }

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            }

            speechRecognizer?.startListening(intent)
            isRecognizerActive = true

            stateMachine.transitionTo(AssistantPhase.COMMAND_LISTENING)
            _serviceState.value = AssistantPhase.COMMAND_LISTENING
            _statusMessage.value = "Listening for your command..."
            updateNotification("NOVA is Listening", "Listening for your command...")
        } catch (e: Exception) {
            Log.e(tag, "Error starting command listener", e)
            isRecognizerActive = false
            resetToWakeWordListening(500)
        }
    }

    // SpeechRecognizer Callbacks
    override fun onReadyForSpeech(params: Bundle?) {
        if (_serviceState.value == AssistantPhase.COMMAND_LISTENING) {
            _statusMessage.value = "Listening for command..."
        }
    }

    override fun onBeginningOfSpeech() {}

    override fun onRmsChanged(rmsdB: Float) {
        _rmsLevel.value = rmsdB
    }

    override fun onBufferReceived(buffer: ByteArray?) {}

    override fun onEndOfSpeech() {
        if (_serviceState.value == AssistantPhase.COMMAND_LISTENING) {
            stateMachine.transitionTo(AssistantPhase.PROCESSING)
            _serviceState.value = AssistantPhase.PROCESSING
            _statusMessage.value = "Processing command..."
            updateNotification("NOVA", "Processing command...")
        }
    }

    override fun onError(error: Int) {
        isRecognizerActive = false
        val current = _serviceState.value

        if (current == AssistantPhase.WAKE_WORD_LISTENING || current == AssistantPhase.IDLE) {
            // Wake word is detected by the Vosk engine, never by SpeechRecognizer: ignore stale callbacks.
            Log.d(tag, "Ignoring SpeechRecognizer error $error while in $current")
            return
        } else if (current == AssistantPhase.COMMAND_LISTENING) {
            when (error) {
                SpeechRecognizer.ERROR_NO_MATCH,
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                    _statusMessage.value = "No command heard. Ready for \"Hey NOVA\"."
                    resetToWakeWordListening(400)
                }
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                    stateMachine.handleRecognitionError(isFatalPermission = true)
                    _serviceState.value = AssistantPhase.ERROR
                    _statusMessage.value = "Microphone permission required"
                }
                else -> {
                    _statusMessage.value = "Speech recognition error ($error)"
                    resetToWakeWordListening(600)
                }
            }
        } else {
            resetToWakeWordListening(500)
        }
    }

    override fun onResults(results: Bundle?) {
        isRecognizerActive = false
        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: arrayListOf()
        val current = _serviceState.value

        if (current == AssistantPhase.WAKE_WORD_LISTENING || current == AssistantPhase.IDLE) {
            // Wake word is detected by the Vosk engine, never by SpeechRecognizer: ignore stale callbacks.
            Log.d(tag, "Ignoring SpeechRecognizer results while in $current")
            return
        } else if (current == AssistantPhase.COMMAND_LISTENING || current == AssistantPhase.PROCESSING) {
            // PROCESSING is included because onEndOfSpeech() moves the phase there BEFORE onResults()
            // arrives; without this the recognised command would be dropped. Duplicate deliveries are
            // blocked by AssistantStateMachine.beginCommandExecution().
            val query = matches.firstOrNull()?.trim() ?: ""
            if (query.isNotEmpty()) {
                val cleanedQuery = stripWakeWordIfPresent(query)
                _lastCommand.value = cleanedQuery
                stateMachine.transitionTo(AssistantPhase.PROCESSING)
                _serviceState.value = AssistantPhase.PROCESSING
                _statusMessage.value = "Executing: \"$cleanedQuery\""
                executeCommand(cleanedQuery)
            } else {
                _statusMessage.value = "No command captured. Ready for \"Hey NOVA\"."
                resetToWakeWordListening(300)
            }
        } else {
            resetToWakeWordListening(200)
        }
    }

    override fun onPartialResults(partialResults: Bundle?) {
        val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        val partial = matches?.firstOrNull()?.trim()
        if (!partial.isNullOrEmpty()) {
            if (_serviceState.value == AssistantPhase.COMMAND_LISTENING) {
                _statusMessage.value = "\"$partial...\""
            }
        }
    }

    override fun onEvent(eventType: Int, params: Bundle?) {}

    /**
     * Inspects candidates for "Hey NOVA", "OK NOVA", or "NOVA".
     * Returns Pair(isWakeWordFound, remainingCommand) or null.
     */
    private fun findWakeWordMatch(candidates: List<String>): Pair<Boolean, String>? {
        for (candidate in candidates) {
            val trimmed = candidate.trim()
            val lower = trimmed.lowercase(Locale.ROOT)

            // 1. "hey nova", "ok nova", "okay nova", "hi nova", "hello nova", "suno nova"
            val patternPrefixed = Regex("^(?:hey|ok|okay|hi|hello|suno|sun)\\s+nova\\b[\\s,:;\\-.]*(.*)$", RegexOption.IGNORE_CASE)
            val match1 = patternPrefixed.find(trimmed)
            if (match1 != null) {
                val cmd = match1.groupValues.getOrNull(1)?.trim() ?: ""
                return Pair(true, cmd)
            }

            // 2. Standalone "nova [command]"
            val patternStandalone = Regex("^nova\\b[\\s,:;\\-.]*(.*)$", RegexOption.IGNORE_CASE)
            val match2 = patternStandalone.find(trimmed)
            if (match2 != null) {
                val cmd = match2.groupValues.getOrNull(1)?.trim() ?: ""
                return Pair(true, cmd)
            }

            // 3. Substring occurrence of wake phrase
            if (lower.contains("hey nova") || lower.contains("ok nova") || lower.contains("okay nova")) {
                val idx = lower.indexOf("nova")
                val cmd = trimmed.substring(idx + 4).trim().removePrefix(",").removePrefix(":").trim()
                return Pair(true, cmd)
            }
        }
        return null
    }

    private fun stripWakeWordIfPresent(rawQuery: String): String {
        val detected = findWakeWordMatch(listOf(rawQuery))
        return if (detected != null && detected.second.isNotBlank()) {
            detected.second
        } else {
            rawQuery
        }
    }

    /**
     * Executes parsed command or routes to Gemini with conversation context.
     * Guarded by stateMachine.beginCommandExecution(currentSessionId) to guarantee
     * that duplicate callbacks cannot execute the same command session twice.
     */
    private fun executeCommand(rawQuery: String) {
        val canExecute = stateMachine.beginCommandExecution(currentSessionId)
        if (!canExecute) {
            Log.w(tag, "Blocked duplicate execution attempt for query: $rawQuery")
            return
        }

        _serviceState.value = AssistantPhase.PROCESSING
        _statusMessage.value = "Executing: \"$rawQuery\""

        val app = NovaApplication.instance

        // Fast offline path: deterministic local parser check (<10ms)
        val fastParsed = app.commandParser.parse(rawQuery)

        if (fastParsed !is NovaCommand.Unknown && fastParsed !is NovaCommand.QueryAi) {
            val result = app.actionExecutor.execute(fastParsed)
            handleCommandResult(rawQuery, result)
            return
        }

        // Natural Language AI path with Gemini & conversation context
        if (app.geminiProvider.isConfigured) {
            _serviceState.value = AssistantPhase.PROCESSING
            _statusMessage.value = "Thinking with Gemini AI..."
            updateNotification("NOVA AI", "Thinking: \"$rawQuery\"")

            serviceScope.launch {
                val history = app.historyRepository.getRecentConversationTurns(maxTurns = 4)
                val aiResponse = app.geminiProvider.generateActionPlan(rawQuery, history)

                aiResponse.fold(
                    onSuccess = { jsonPlan ->
                        val mapped = app.actionDispatcher.validateAndMap(jsonPlan)
                        mapped.fold(
                            onSuccess = { command ->
                                val result = app.actionExecutor.execute(command)
                                handleCommandResult(rawQuery, result)
                            },
                            onFailure = { validationError ->
                                Log.w(tag, "Security allowlist rejected: ${validationError.message}")
                                val failResult = CommandResult.Failure(
                                    feedbackSpeech = "That action is not permitted on this phone.",
                                    errorMessage = validationError.message ?: "Security allowlist check failed"
                                )
                                handleCommandResult(rawQuery, failResult)
                            }
                        )
                    },
                    onFailure = { networkError ->
                        Log.e(tag, "Gemini network error: ${networkError.message}")
                        val failResult = CommandResult.Failure(
                            feedbackSpeech = networkError.localizedMessage ?: "Could not reach Gemini AI. Check internet connection.",
                            errorMessage = networkError.localizedMessage ?: "AI network error"
                        )
                        handleCommandResult(rawQuery, failResult)
                    }
                )
            }
        } else {
            val fallbackResult = if (fastParsed is NovaCommand.QueryAi) {
                CommandResult.Failure(
                    feedbackSpeech = "To answer questions and understand natural Hindi and Hinglish commands, add a free Gemini API key in Settings.",
                    errorMessage = "Gemini API key not configured"
                )
            } else {
                app.actionExecutor.execute(fastParsed)
            }
            handleCommandResult(rawQuery, fallbackResult)
        }
    }

    private fun handleCommandResult(rawQuery: String, result: CommandResult) {
        _lastResult.value = result
        stateMachine.transitionTo(AssistantPhase.SPEAKING)
        _serviceState.value = AssistantPhase.SPEAKING
        _statusMessage.value = result.feedbackSpeech
        updateNotification("NOVA: ${result.displayTitle}", result.feedbackSpeech)

        val app = NovaApplication.instance

        // Ensure recognizer is completely stopped while speaking so NOVA does not hear itself
        destroyRecognizer()

        app.tts.speak(result.feedbackSpeech) {
            app.historyRepository.addEntry(
                rawQuery = rawQuery,
                actionType = result.displayTitle,
                resultText = result.feedbackSpeech,
                isSuccess = result is CommandResult.Success
            )

            // Safe post-utterance delay before resuming wake-word listening loop
            mainHandler.postDelayed({
                if (isServiceActive) {
                    startWakeWordListening()
                }
            }, 350)
        }
    }

    fun stopSpeaking() {
        NovaApplication.instance.tts.stop()
        resetToWakeWordListening(200)
    }

    private fun resetToWakeWordListening(delayMs: Long) {
        if (!isServiceActive) return
        destroyRecognizer()
        mainHandler.postDelayed({
            if (isServiceActive) {
                startWakeWordListening()
            }
        }, delayMs)
    }

    private fun destroyRecognizer() {
        isRecognizerActive = false
        try {
            speechRecognizer?.cancel()
            speechRecognizer?.destroy()
            speechRecognizer = null
        } catch (e: Exception) {
            Log.w(tag, "Error destroying SpeechRecognizer", e)
        }
    }

    /**
     * Completely stops assistant service
     */
    private fun stopAssistant() {
        isServiceActive = false
        isRunning = false
        mainHandler.removeCallbacksAndMessages(null)
        stateMachine.stopSession()
        stopWakeWordCapture()
        destroyRecognizer()
        releaseWakeWordEngine()
        NovaApplication.instance.tts.stop()

        _serviceState.value = AssistantPhase.STOPPED
        _statusMessage.value = "NOVA is stopped"
        stopForeground(true)
        stopSelf()
    }

    private fun buildNotification(title: String, contentText: String): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val openPendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        // Push-to-Talk action from notification
        val listenIntent = Intent(this, NovaVoiceService::class.java).apply {
            action = ACTION_LISTEN
        }
        val listenPendingIntent = PendingIntent.getService(
            this,
            2,
            listenIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val stopIntent = Intent(this, NovaVoiceService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, channelId)
            .setContentTitle(title)
            .setContentText(contentText)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentIntent(openPendingIntent)
            .addAction(android.R.drawable.ic_btn_speak_now, "Speak", listenPendingIntent)
            .addAction(android.R.drawable.ic_media_pause, "Stop", stopPendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    private fun updateNotification(title: String, text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(notificationId, buildNotification(title, text))
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "NOVA Voice Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows live status while NOVA is ready to assist you"
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        stopAssistant()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "com.nova.assistant.ACTION_START"
        const val ACTION_STOP = "com.nova.assistant.ACTION_STOP"
        const val ACTION_LISTEN = "com.nova.assistant.ACTION_LISTEN"
        const val ACTION_STOP_SPEAKING = "com.nova.assistant.ACTION_STOP_SPEAKING"

        private const val MAX_WAKE_CAPTURE_RETRIES = 3
        private const val WAKE_ACK_WATCHDOG_MS = 4000L

        var isRunning: Boolean = false
            private set

        private val _serviceState = MutableStateFlow(AssistantPhase.STOPPED)
        val serviceState: StateFlow<AssistantPhase> = _serviceState.asStateFlow()

        private val _statusMessage = MutableStateFlow("NOVA is ready to start")
        val statusMessage: StateFlow<String> = _statusMessage.asStateFlow()

        private val _lastCommand = MutableStateFlow("")
        val lastCommand: StateFlow<String> = _lastCommand.asStateFlow()

        private val _lastResult = MutableStateFlow<CommandResult?>(null)
        val lastResult: StateFlow<CommandResult?> = _lastResult.asStateFlow()

        private val _rmsLevel = MutableStateFlow(0f)
        val rmsLevel: StateFlow<Float> = _rmsLevel.asStateFlow()

        fun startService(context: Context) {
            val intent = Intent(context, NovaVoiceService::class.java).apply {
                action = ACTION_START
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun triggerListening(context: Context) {
            val intent = Intent(context, NovaVoiceService::class.java).apply {
                action = ACTION_LISTEN
            }
            context.startService(intent)
        }

        fun stopSpeaking(context: Context) {
            val intent = Intent(context, NovaVoiceService::class.java).apply {
                action = ACTION_STOP_SPEAKING
            }
            context.startService(intent)
        }

        fun stopService(context: Context) {
            val intent = Intent(context, NovaVoiceService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }
}
