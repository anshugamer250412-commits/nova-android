package com.nova.assistant

import com.nova.assistant.service.AssistantPhase
import com.nova.assistant.service.AssistantStateMachine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class AssistantStateMachineTest {

    private lateinit var stateMachine: AssistantStateMachine

    @Before
    fun setUp() {
        stateMachine = AssistantStateMachine()
    }

    @Test
    fun testValidLifecycleTransitions() {
        assertEquals(AssistantPhase.STOPPED, stateMachine.currentPhase)

        // 1. STOPPED -> STARTING
        assertTrue(stateMachine.transitionTo(AssistantPhase.STARTING))
        assertEquals(AssistantPhase.STARTING, stateMachine.currentPhase)

        // 2. STARTING -> WAKE_WORD_LISTENING
        assertTrue(stateMachine.transitionTo(AssistantPhase.WAKE_WORD_LISTENING))
        assertEquals(AssistantPhase.WAKE_WORD_LISTENING, stateMachine.currentPhase)

        // 3. Wake Word Detected -> COMMAND_LISTENING
        assertTrue(stateMachine.transitionTo(AssistantPhase.COMMAND_LISTENING))
        assertEquals(AssistantPhase.COMMAND_LISTENING, stateMachine.currentPhase)

        // 4. Command Heard -> PROCESSING
        assertTrue(stateMachine.transitionTo(AssistantPhase.PROCESSING))
        assertEquals(AssistantPhase.PROCESSING, stateMachine.currentPhase)

        // 5. Action Handled -> SPEAKING
        assertTrue(stateMachine.transitionTo(AssistantPhase.SPEAKING))
        assertEquals(AssistantPhase.SPEAKING, stateMachine.currentPhase)

        // 6. Speech Complete -> WAKE_WORD_LISTENING
        assertTrue(stateMachine.transitionTo(AssistantPhase.WAKE_WORD_LISTENING))
        assertEquals(AssistantPhase.WAKE_WORD_LISTENING, stateMachine.currentPhase)
    }

    @Test
    fun testRejectsInvalidTransitions() {
        assertEquals(AssistantPhase.STOPPED, stateMachine.currentPhase)

        // STOPPED cannot jump directly to SPEAKING or COMMAND_LISTENING
        assertFalse(stateMachine.canTransitionTo(AssistantPhase.SPEAKING))
        assertFalse(stateMachine.transitionTo(AssistantPhase.SPEAKING))
        assertEquals(AssistantPhase.STOPPED, stateMachine.currentPhase)

        assertFalse(stateMachine.canTransitionTo(AssistantPhase.COMMAND_LISTENING))
        assertFalse(stateMachine.transitionTo(AssistantPhase.COMMAND_LISTENING))
        assertEquals(AssistantPhase.STOPPED, stateMachine.currentPhase)
    }

    @Test
    fun testCommandTimeoutReturnsToWakeWordListening() {
        stateMachine.transitionTo(AssistantPhase.STARTING)
        stateMachine.transitionTo(AssistantPhase.WAKE_WORD_LISTENING)
        stateMachine.transitionTo(AssistantPhase.COMMAND_LISTENING)

        // Command times out with silence -> transitions back to WAKE_WORD_LISTENING
        assertTrue(stateMachine.transitionTo(AssistantPhase.WAKE_WORD_LISTENING))
        assertEquals(AssistantPhase.WAKE_WORD_LISTENING, stateMachine.currentPhase)
    }

    @Test
    fun testDuplicateCallbacksCannotExecuteTwice() {
        val sessionId = stateMachine.startNewSession()
        stateMachine.transitionTo(AssistantPhase.WAKE_WORD_LISTENING)
        stateMachine.transitionTo(AssistantPhase.COMMAND_LISTENING)
        stateMachine.transitionTo(AssistantPhase.PROCESSING)

        // First execution attempt succeeds
        assertTrue(stateMachine.beginCommandExecution(sessionId))

        // Duplicate callback on same session ID must be rejected
        assertFalse("Duplicate callback must not execute twice", stateMachine.beginCommandExecution(sessionId))
    }

    @Test
    fun testBoundedRecoveryOnErrors() {
        stateMachine.transitionTo(AssistantPhase.STARTING)
        stateMachine.transitionTo(AssistantPhase.WAKE_WORD_LISTENING)

        // Transient errors recover up to 3 times
        assertTrue(stateMachine.handleRecognitionError(isFatalPermission = false))
        assertEquals(1, stateMachine.errorRecoveryAttempts)
        assertEquals(AssistantPhase.WAKE_WORD_LISTENING, stateMachine.currentPhase)

        assertTrue(stateMachine.handleRecognitionError(isFatalPermission = false))
        assertEquals(2, stateMachine.errorRecoveryAttempts)

        assertTrue(stateMachine.handleRecognitionError(isFatalPermission = false))
        assertEquals(3, stateMachine.errorRecoveryAttempts)

        // 4th error exceeds max attempts -> enters ERROR state
        assertFalse(stateMachine.handleRecognitionError(isFatalPermission = false))
        assertEquals(AssistantPhase.ERROR, stateMachine.currentPhase)
    }

    @Test
    fun testFatalPermissionErrorEntersErrorImmediately() {
        stateMachine.transitionTo(AssistantPhase.STARTING)
        stateMachine.transitionTo(AssistantPhase.WAKE_WORD_LISTENING)

        // Fatal permission denial never retries blindly
        val canRecover = stateMachine.handleRecognitionError(isFatalPermission = true)
        assertFalse(canRecover)
        assertEquals(AssistantPhase.ERROR, stateMachine.currentPhase)
    }

    @Test
    fun testExplicitStopHaltsLifecycle() {
        stateMachine.startNewSession()
        stateMachine.transitionTo(AssistantPhase.WAKE_WORD_LISTENING)
        stateMachine.transitionTo(AssistantPhase.COMMAND_LISTENING)

        // User explicit stop
        stateMachine.stopSession()
        assertEquals(AssistantPhase.STOPPED, stateMachine.currentPhase)

        // Cannot transition without restarting session
        assertFalse(stateMachine.transitionTo(AssistantPhase.COMMAND_LISTENING))
    }
}
