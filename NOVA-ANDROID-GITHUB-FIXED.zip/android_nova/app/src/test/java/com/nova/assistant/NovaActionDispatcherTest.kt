package com.nova.assistant

import com.nova.assistant.ai.NovaActionDispatcher
import com.nova.assistant.parser.NovaCommand
import com.nova.assistant.parser.SearchPlatform
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class NovaActionDispatcherTest {

    private lateinit var dispatcher: NovaActionDispatcher

    @Before
    fun setUp() {
        dispatcher = NovaActionDispatcher()
    }

    @Test
    fun testValidOpenAppAction() {
        val json = """{"actionType":"OPEN_APP","appName":"youtube","speechResponse":"Opening YouTube."}"""
        val result = dispatcher.validateAndMap(json)
        assertTrue(result.isSuccess)
        val cmd = result.getOrThrow()
        assertTrue(cmd is NovaCommand.OpenApp)
        assertEquals("youtube", (cmd as NovaCommand.OpenApp).appQuery)
    }

    @Test
    fun testValidSearchAction() {
        val json = """{"actionType":"SEARCH_YOUTUBE","searchQuery":"Minecraft building tips","speechResponse":"Searching YouTube."}"""
        val result = dispatcher.validateAndMap(json)
        assertTrue(result.isSuccess)
        val cmd = result.getOrThrow()
        assertTrue(cmd is NovaCommand.WebSearch)
        val ws = cmd as NovaCommand.WebSearch
        assertEquals("Minecraft building tips", ws.query)
        assertEquals(SearchPlatform.YOUTUBE, ws.platform)
    }

    @Test
    fun testValidToggleFlashlightAction() {
        val json = """{"actionType":"TOGGLE_FLASHLIGHT","state":true,"speechResponse":"Flashlight on."}"""
        val result = dispatcher.validateAndMap(json)
        assertTrue(result.isSuccess)
        val cmd = result.getOrThrow()
        assertTrue(cmd is NovaCommand.ToggleFlashlight)
        assertEquals(true, (cmd as NovaCommand.ToggleFlashlight).desiredState)
    }

    @Test
    fun testValidConverseAction() {
        val json = """{"actionType":"CONVERSE","speechResponse":"The capital of France is Paris."}"""
        val result = dispatcher.validateAndMap(json)
        assertTrue(result.isSuccess)
        val cmd = result.getOrThrow()
        assertTrue(cmd is NovaCommand.QueryAi)
        assertEquals("The capital of France is Paris.", (cmd as NovaCommand.QueryAi).question)
    }

    @Test
    fun testBlocksUnauthorizedShellAction() {
        val maliciousJson = """{"actionType":"RUN_SHELL","command":"rm -rf /"}"""
        val result = dispatcher.validateAndMap(maliciousJson)
        assertTrue(result.isFailure)
        assertTrue(result.exceptionOrNull() is SecurityException)
    }

    @Test
    fun testBlocksArbitraryScriptAction() {
        val maliciousJson = """{"actionType":"EXECUTE_SCRIPT","script":"install_malware()"}"""
        val result = dispatcher.validateAndMap(maliciousJson)
        assertTrue(result.isFailure)
        assertTrue(result.exceptionOrNull() is SecurityException)
    }

    @Test
    fun testHandlesMalformedJsonGracefully() {
        val badJson = "not a json string at all"
        val result = dispatcher.validateAndMap(badJson)
        assertTrue(result.isFailure)
    }
}
