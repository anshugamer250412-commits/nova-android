package com.nova.assistant

import com.nova.assistant.wakeword.RecognizedWord
import com.nova.assistant.wakeword.VoskHypothesis
import com.nova.assistant.wakeword.WakePhraseMatcher
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Logic tests for the decision made on top of Vosk's output. These feed JSON in the documented Vosk
 * result format; they prove the matching rules, NOT that the acoustic model recognises speech
 * (that needs the instrumented test).
 */
class WakePhraseMatcherTest {

    private val phrase = "Hey NOVA"

    private fun finalJson(text: String, vararg words: Pair<String, Double>): String {
        val items = words.joinToString(",") { (w, c) ->
            """{"conf":$c,"end":1.0,"start":0.5,"word":"$w"}"""
        }
        return """{"result":[$items],"text":"$text"}"""
    }

    @Test
    fun parsesPartialResult() {
        assertEquals("hey nova", WakePhraseMatcher.parsePartial("""{"partial" : "hey nova"}"""))
        assertEquals("", WakePhraseMatcher.parsePartial("not json"))
    }

    @Test
    fun parsesFinalResultWithWordConfidences() {
        val parsed = WakePhraseMatcher.parseResult(finalJson("hey nova", "hey" to 0.93, "nova" to 0.88))
        assertEquals("hey nova", parsed.text)
        assertEquals(listOf(RecognizedWord("hey", 0.93f), RecognizedWord("nova", 0.88f)), parsed.words)
    }

    @Test
    fun malformedJsonYieldsEmptyHypothesis() {
        val parsed = WakePhraseMatcher.parseResult("{broken")
        assertEquals("", parsed.text)
        assertTrue(parsed.words.isEmpty())
    }

    @Test
    fun acceptsOnlyTheExactConsecutivePhrase() {
        assertTrue(WakePhraseMatcher.containsPhrase("hey nova", phrase))
        assertTrue(WakePhraseMatcher.containsPhrase("HEY NOVA", phrase))
        assertTrue(WakePhraseMatcher.containsPhrase("hey nova [unk]", phrase))
        assertTrue(WakePhraseMatcher.containsPhrase("[unk] hey nova", phrase))
    }

    @Test
    fun rejectsEverythingElse() {
        val rejected = listOf(
            "", "[unk]", "nova", "hey", "ok nova", "okay nova", "hey nora", "hey november",
            "hey [unk] nova", "nova hey", "pass the salt", "hello there"
        )
        for (text in rejected) {
            assertFalse("'$text' must not match", WakePhraseMatcher.containsPhrase(text, phrase))
        }
    }

    @Test
    fun lowConfidenceWordsAreRejected() {
        val weak = WakePhraseMatcher.parseResult(finalJson("hey nova", "hey" to 0.95, "nova" to 0.30))
        assertFalse(WakePhraseMatcher.isWakeWord(weak, phrase, minConfidence = 0.5f))

        val strong = WakePhraseMatcher.parseResult(finalJson("hey nova", "hey" to 0.95, "nova" to 0.80))
        assertTrue(WakePhraseMatcher.isWakeWord(strong, phrase, minConfidence = 0.5f))
    }

    @Test
    fun hypothesisWithoutWordsStillRequiresTheText() {
        assertTrue(WakePhraseMatcher.isWakeWord(VoskHypothesis("hey nova", emptyList()), phrase, 0.5f))
        assertFalse(WakePhraseMatcher.isWakeWord(VoskHypothesis("hey nora", emptyList()), phrase, 0.5f))
    }
}
