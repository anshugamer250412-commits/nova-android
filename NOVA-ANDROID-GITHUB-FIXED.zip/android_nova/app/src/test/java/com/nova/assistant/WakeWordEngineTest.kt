package com.nova.assistant

import com.nova.assistant.wakeword.VoskWakeWordEngine
import com.nova.assistant.wakeword.WakeWordState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * JVM unit tests for the failure/lifecycle paths of VoskWakeWordEngine that do not need the native
 * Vosk library or a model. Real phrase detection is covered by the instrumented test
 * (androidTest/.../WakeWordInstrumentedTest.kt), which loads the real model on a device/emulator.
 */
class WakeWordEngineTest {

    @Test
    fun initializationWithoutContextFailsHonestly() {
        val engine = VoskWakeWordEngine(keyword = "Hey NOVA", modelAssetDir = "non_existent_model")
        val result = engine.initialize(null)

        assertTrue("Initialization without context must fail", result.isFailure)
        assertFalse("Engine must not report ready", engine.isReady)
        assertEquals(WakeWordState.ERROR, engine.state)
        assertNotNull(engine.lastError)
    }

    @Test
    fun uninitializedEngineNeverDetects() {
        val engine = VoskWakeWordEngine()
        val loudFrame = ShortArray(1600) { 20000 } // very loud, but loudness is not a wake word
        assertFalse(engine.processAudioFrame(loudFrame, loudFrame.size))
        assertFalse(engine.processAudioFrame(ShortArray(0), 0))
        assertEquals(WakeWordState.UNINITIALIZED, engine.state)
    }

    @Test
    fun releaseIsIdempotent() {
        val engine = VoskWakeWordEngine()
        engine.release()
        engine.release()
        assertFalse(engine.isReady)
        assertEquals(WakeWordState.UNINITIALIZED, engine.state)
    }
}
