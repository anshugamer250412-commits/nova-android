package com.nova.assistant

import com.nova.assistant.history.ConversationTurn
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ConversationContextTest {

    @Test
    fun testConversationTurnIntegrity() {
        val turn = ConversationTurn(
            user = "Who was the first president of India?",
            assistant = "Dr. Rajendra Prasad was the first president of India."
        )
        assertEquals("Who was the first president of India?", turn.user)
        assertEquals("Dr. Rajendra Prasad was the first president of India.", turn.assistant)
    }

    @Test
    fun testBoundedContextLimiting() {
        val turns = mutableListOf<ConversationTurn>()
        for (i in 1..10) {
            turns.add(ConversationTurn("Question $i", "Answer $i"))
        }

        // Bounded context to last 4 turns
        val bounded = turns.takeLast(4)
        assertEquals(4, bounded.size)
        assertEquals("Question 7", bounded.first().user)
        assertEquals("Question 10", bounded.last().user)
    }
}
