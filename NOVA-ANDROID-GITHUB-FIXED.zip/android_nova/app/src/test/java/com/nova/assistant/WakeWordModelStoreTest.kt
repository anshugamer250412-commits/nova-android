package com.nova.assistant

import com.nova.assistant.wakeword.WakeWordModelStore
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.assertFalse
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

/**
 * Tests the model validation rules against small synthetic directories. They prove the validator's
 * behaviour; they do NOT prove that the real Vosk model loads (see the instrumented test).
 */
class WakeWordModelStoreTest {

    @get:Rule
    val tmp = TemporaryFolder()

    private fun buildModelDir(words: List<String>, skip: Set<String> = emptySet()): File {
        val dir = tmp.newFolder()
        for (rel in WakeWordModelStore.REQUIRED_FILES) {
            if (rel in skip) continue
            val f = File(dir, rel)
            f.parentFile!!.mkdirs()
            if (rel == "graph/words.txt") {
                f.writeText(words.withIndex().joinToString("\n") { (i, w) -> "$w $i" })
            } else {
                f.writeText("x")
            }
        }
        return dir
    }

    @Test
    fun nonexistentDirectoryFails() {
        assertTrue(WakeWordModelStore.validate(File(tmp.root, "nope")).isFailure)
    }

    @Test
    fun emptyDirectoryFails() {
        assertTrue(WakeWordModelStore.validate(tmp.newFolder()).isFailure)
    }

    @Test
    fun missingGraphFileFails() {
        val dir = buildModelDir(listOf("hey", "nova"), skip = setOf("graph/HCLr.fst"))
        val result = WakeWordModelStore.validate(dir)
        assertTrue(result.isFailure)
        assertTrue(result.exceptionOrNull()!!.message!!.contains("graph/HCLr.fst"))
    }

    @Test
    fun vocabularyWithoutNovaFails() {
        val dir = buildModelDir(listOf("hey", "hello", "world"))
        val result = WakeWordModelStore.validate(dir)
        assertTrue(result.isFailure)
        assertTrue(result.exceptionOrNull()!!.message!!.contains("nova"))
    }

    @Test
    fun completeModelWithPhraseVocabularyPasses() {
        val dir = buildModelDir(listOf("<eps>", "hello", "hey", "nova", "world"))
        assertTrue(WakeWordModelStore.validate(dir).isSuccess)
    }

    @Test
    fun vocabularyMatchIsExactWordNotPrefix() {
        // "november" must not satisfy "nova"
        val dir = buildModelDir(listOf("hey", "november", "novas"))
        assertFalse(WakeWordModelStore.validate(dir).isSuccess)
        assertEquals(listOf("hey", "nova"), WakeWordModelStore.REQUIRED_VOCABULARY)
    }
}
