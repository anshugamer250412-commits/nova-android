package com.nova.assistant

import com.nova.assistant.parser.CommandResult
import com.nova.assistant.parser.NovaCommand
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test

class CommandResultTest {

    @Test
    fun testSuccessResultPolymorphism() {
        val result: CommandResult = CommandResult.Success(
            feedbackSpeech = "Flashlight turned on.",
            displayTitle = "Flashlight",
            detail = "Torch set to on"
        )
        assertEquals("Flashlight turned on.", result.feedbackSpeech)
        assertEquals("Flashlight", result.displayTitle)
    }

    @Test
    fun testFailureResultPolymorphism() {
        val result: CommandResult = CommandResult.Failure(
            feedbackSpeech = "Could not reach AI assistant.",
            errorMessage = "HTTP 500"
        )
        assertEquals("Could not reach AI assistant.", result.feedbackSpeech)
        assertEquals("HTTP 500", result.displayTitle)
    }

    @Test
    fun testNeedsConfirmationPolymorphism() {
        val pending = NovaCommand.CallContact("Rahul")
        val result: CommandResult = CommandResult.NeedsConfirmation(
            prompt = "Do you want to call Rahul?",
            pendingCommand = pending
        )
        assertEquals("Do you want to call Rahul?", result.feedbackSpeech)
        assertEquals("Confirmation Needed", result.displayTitle)
        assertNotNull((result as CommandResult.NeedsConfirmation).pendingCommand)
    }
}
