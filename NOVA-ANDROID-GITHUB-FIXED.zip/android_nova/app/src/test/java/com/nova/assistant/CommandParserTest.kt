package com.nova.assistant

import com.nova.assistant.parser.CommandParser
import com.nova.assistant.parser.NovaCommand
import com.nova.assistant.parser.SearchPlatform
import com.nova.assistant.parser.SettingTarget
import com.nova.assistant.parser.VolumeDirection
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class CommandParserTest {

    private lateinit var parser: CommandParser

    @Before
    fun setUp() {
        parser = CommandParser()
    }

    @Test
    fun testEmptyAndBlankInput() {
        val resultEmpty = parser.parse("")
        assertTrue(resultEmpty is NovaCommand.Unknown)

        val resultBlank = parser.parse("   ")
        assertTrue(resultBlank is NovaCommand.Unknown)
    }

    @Test
    fun testWakeWordStripping() {
        val cmd1 = parser.parse("Hey NOVA open YouTube")
        assertTrue(cmd1 is NovaCommand.OpenApp)
        assertEquals("youtube", (cmd1 as NovaCommand.OpenApp).appQuery)

        val cmd2 = parser.parse("ok nova torch on karo")
        assertTrue(cmd2 is NovaCommand.ToggleFlashlight)
        assertEquals(true, (cmd2 as NovaCommand.ToggleFlashlight).desiredState)

        val cmd3 = parser.parse("Hey NOVA, YouTube par Minecraft survival search karo.")
        assertTrue(cmd3 is NovaCommand.WebSearch)
        val ws = cmd3 as NovaCommand.WebSearch
        assertEquals("minecraft survival", ws.query)
        assertEquals(SearchPlatform.YOUTUBE, ws.platform)
    }

    @Test
    fun testEnglishFlashlightCommands() {
        val onCmd = parser.parse("turn on flashlight")
        assertTrue(onCmd is NovaCommand.ToggleFlashlight)
        assertEquals(true, (onCmd as NovaCommand.ToggleFlashlight).desiredState)

        val offCmd = parser.parse("turn off the torch")
        assertTrue(offCmd is NovaCommand.ToggleFlashlight)
        assertEquals(false, (offCmd as NovaCommand.ToggleFlashlight).desiredState)

        val toggleCmd = parser.parse("toggle flashlight")
        assertTrue(toggleCmd is NovaCommand.ToggleFlashlight)
        assertEquals(null, (toggleCmd as NovaCommand.ToggleFlashlight).desiredState)
    }

    @Test
    fun testHindiFlashlightCommands() {
        val onHindi = parser.parse("flashlight on karo")
        assertTrue(onHindi is NovaCommand.ToggleFlashlight)
        assertEquals(true, (onHindi as NovaCommand.ToggleFlashlight).desiredState)

        val bandKarDo = parser.parse("flashlight band kar do")
        assertTrue(bandKarDo is NovaCommand.ToggleFlashlight)
        assertEquals(false, (bandKarDo as NovaCommand.ToggleFlashlight).desiredState)

        val jalao = parser.parse("torch jalao")
        assertTrue(jalao is NovaCommand.ToggleFlashlight)
        assertEquals(true, (jalao as NovaCommand.ToggleFlashlight).desiredState)

        val bujhao = parser.parse("torch bujhao")
        assertTrue(bujhao is NovaCommand.ToggleFlashlight)
        assertEquals(false, (bujhao as NovaCommand.ToggleFlashlight).desiredState)
    }

    @Test
    fun testVolumeAdjustments() {
        val volUp = parser.parse("volume up")
        assertTrue(volUp is NovaCommand.AdjustVolume)
        assertEquals(VolumeDirection.UP, (volUp as NovaCommand.AdjustVolume).direction)

        val volBadhao = parser.parse("volume badhao")
        assertTrue(volBadhao is NovaCommand.AdjustVolume)
        assertEquals(VolumeDirection.UP, (volBadhao as NovaCommand.AdjustVolume).direction)

        val volDown = parser.parse("aawaz kam karo")
        assertTrue(volDown is NovaCommand.AdjustVolume)
        assertEquals(VolumeDirection.DOWN, (volDown as NovaCommand.AdjustVolume).direction)

        val mute = parser.parse("mute")
        assertTrue(mute is NovaCommand.AdjustVolume)
        assertEquals(VolumeDirection.MUTE, (mute as NovaCommand.AdjustVolume).direction)
    }

    @Test
    fun testCallsAndContacts() {
        val callMom = parser.parse("call Mom")
        assertTrue(callMom is NovaCommand.CallContact)
        assertEquals("mom", (callMom as NovaCommand.CallContact).contactName)

        val callRahul = parser.parse("Call Rahul.")
        assertTrue(callRahul is NovaCommand.CallContact)
        assertEquals("rahul", (callRahul as NovaCommand.CallContact).contactName)

        val rahulLagao = parser.parse("Rahul ko phone lagao.")
        assertTrue(rahulLagao is NovaCommand.CallContact)
        assertEquals("rahul", (rahulLagao as NovaCommand.CallContact).contactName)

        val rahulCallKaro = parser.parse("Rahul ko call karo.")
        assertTrue(rahulCallKaro is NovaCommand.CallContact)
        assertEquals("rahul", (rahulCallKaro as NovaCommand.CallContact).contactName)

        val findAmit = parser.parse("Find Amit in my contacts.")
        assertTrue(findAmit is NovaCommand.CallContact)
        assertEquals("amit", (findAmit as NovaCommand.CallContact).contactName)
    }

    @Test
    fun testYouTubeSearches() {
        val yt1 = parser.parse("Hey NOVA, YouTube par Minecraft survival search karo.")
        assertTrue(yt1 is NovaCommand.WebSearch)
        val ws1 = yt1 as NovaCommand.WebSearch
        assertEquals("minecraft survival", ws1.query)
        assertEquals(SearchPlatform.YOUTUBE, ws1.platform)

        val yt2 = parser.parse("YouTube pe latest gaming videos search karo.")
        assertTrue(yt2 is NovaCommand.WebSearch)
        val ws2 = yt2 as NovaCommand.WebSearch
        assertEquals("latest gaming videos", ws2.query)
        assertEquals(SearchPlatform.YOUTUBE, ws2.platform)

        val yt3 = parser.parse("Search YouTube for Minecraft shaders.")
        assertTrue(yt3 is NovaCommand.WebSearch)
        val ws3 = yt3 as NovaCommand.WebSearch
        assertEquals("minecraft shaders", ws3.query)
        assertEquals(SearchPlatform.YOUTUBE, ws3.platform)

        val yt4 = parser.parse("YouTube pe Free Fire search karo.")
        assertTrue(yt4 is NovaCommand.WebSearch)
        val ws4 = yt4 as NovaCommand.WebSearch
        assertEquals("free fire", ws4.query)
        assertEquals(SearchPlatform.YOUTUBE, ws4.platform)
    }

    @Test
    fun testPlayStoreCommands() {
        val ps1 = parser.parse("Play Store par Minecraft search karo.")
        assertTrue(ps1 is NovaCommand.PlayStoreSearch)
        assertEquals("minecraft", (ps1 as NovaCommand.PlayStoreSearch).query)

        val ps2 = parser.parse("Find WhatsApp on Play Store.")
        assertTrue(ps2 is NovaCommand.PlayStoreSearch)
        assertEquals("whatsapp", (ps2 as NovaCommand.PlayStoreSearch).query)

        val ps3 = parser.parse("Play Store mein photo editor search karo.")
        assertTrue(ps3 is NovaCommand.PlayStoreSearch)
        assertEquals("photo editor", (ps3 as NovaCommand.PlayStoreSearch).query)

        val psDownload = parser.parse("download Spotify")
        assertTrue(psDownload is NovaCommand.PlayStoreSearch)
        assertEquals("spotify", (psDownload as NovaCommand.PlayStoreSearch).query)

        val psInstall = parser.parse("install WhatsApp")
        assertTrue(psInstall is NovaCommand.PlayStoreSearch)
        assertEquals("whatsapp", (psInstall as NovaCommand.PlayStoreSearch).query)

        val psOpen = parser.parse("Play Store kholo.")
        assertTrue(psOpen is NovaCommand.OpenApp)
        assertEquals("play store", (psOpen as NovaCommand.OpenApp).appQuery)
    }

    @Test
    fun testSettingsCommands() {
        val wifi1 = parser.parse("Wi-Fi settings kholo.")
        assertTrue(wifi1 is NovaCommand.OpenSettings)
        assertEquals(SettingTarget.Wifi, (wifi1 as NovaCommand.OpenSettings).target)

        val bt1 = parser.parse("Bluetooth settings kholo.")
        assertTrue(bt1 is NovaCommand.OpenSettings)
        assertEquals(SettingTarget.Bluetooth, (bt1 as NovaCommand.OpenSettings).target)

        val bt2 = parser.parse("Open Bluetooth settings.")
        assertTrue(bt2 is NovaCommand.OpenSettings)
        assertEquals(SettingTarget.Bluetooth, (bt2 as NovaCommand.OpenSettings).target)

        val generalSettings = parser.parse("Open settings.")
        assertTrue(generalSettings is NovaCommand.OpenSettings)
        assertEquals(SettingTarget.General, (generalSettings as NovaCommand.OpenSettings).target)
    }

    @Test
    fun testTimeQuery() {
        val timeCmd = parser.parse("Abhi kitne baje hain?")
        assertTrue(timeCmd is NovaCommand.SystemStatus)
        assertEquals("time", (timeCmd as NovaCommand.SystemStatus).metric)
    }

    @Test
    fun testHistoryAndHelp() {
        val historyCmd = parser.parse("show my recent commands")
        assertTrue(historyCmd is NovaCommand.ShowHistory)

        val historyHindi = parser.parse("history dikhao")
        assertTrue(historyHindi is NovaCommand.ShowHistory)

        val helpCmd = parser.parse("what can you do")
        assertTrue(helpCmd is NovaCommand.ShowHelp)
    }

    @Test
    fun testAiQuestions() {
        val question = parser.parse("What is the speed of light?")
        assertTrue(question is NovaCommand.QueryAi)
        assertEquals("What is the speed of light?", (question as NovaCommand.QueryAi).question)
    }
}
