/**
 * Mirror of core NOVA pure logic algorithms for deterministic verification in Node/browser.
 */

export interface ParsedCommand {
  type: string;
  target?: string;
  query?: string;
  state?: boolean | null;
  rawInput: string;
}

export function parseVoiceCommand(rawText: string): ParsedCommand {
  let normalized = rawText.trim().toLowerCase();
  // Strip wake word prefix
  normalized = normalized.replace(/^(?:hey|hi|hello|ok|okay)?\s*nova[,:\s]*/, '').trim();
  // Normalize punctuation: strip leading and trailing punctuation marks
  normalized = normalized.replace(/^[\s,.:;!?-]+|[\s,.:;!?-]+$/g, '').trim();

  if (!normalized) {
    return { type: 'UNKNOWN', rawInput: rawText };
  }

  // 1. Wi-Fi Settings
  if (/\b(?:turn\s+(?:on|off)|enable|disable|switch\s+(?:on|off)|chalu|band)?\s*(?:the\s+)?(?:wi-?fi|wifi|internet|network)(?:\s+(?:on|off|chalu|band|kholo|settings?|options?|chalu\s+karo|band\s+karo))?\b|^wi-?fi$/.test(normalized) &&
      (normalized.includes('on') || normalized.includes('off') || normalized.includes('wifi') || normalized.includes('wi-fi') || normalized.includes('karo') || normalized.includes('setting'))) {
    return { type: 'OPEN_SETTINGS', target: 'wifi', rawInput: rawText };
  }

  // 2. Bluetooth Settings
  if (/\b(?:turn\s+(?:on|off)|enable|disable|switch\s+(?:on|off)|chalu|band)?\s*(?:the\s+)?(?:bluetooth|bt)(?:\s+(?:on|off|chalu|band|kholo|settings?|options?|chalu\s+karo|band\s+karo))?\b|^bluetooth$/.test(normalized) &&
      (normalized.includes('on') || normalized.includes('off') || normalized.includes('bluetooth') || normalized.includes('bt') || normalized.includes('karo') || normalized.includes('setting'))) {
    return { type: 'OPEN_SETTINGS', target: 'bluetooth', rawInput: rawText };
  }

  // 3. Play Store Search / Install / Download
  const playStoreMatch = normalized.match(/^(?:open\s+play\s*store\s+(?:and\s+)?(?:find|search(?:\s+for)?)|search\s+play\s*store(?:\s+for)?|find\s+(.*?)\s+on\s+play\s*store|download|install|play\s*store\s+(?:par|pe|mein|me)\s+(.*?)\s+(?:search\s+karo|dhoondo|search))\s*(.*)$/);
  if (playStoreMatch) {
    const raw = (playStoreMatch[1] || playStoreMatch[2] || playStoreMatch[3] || '').trim();
    const query = raw
      .replace(/^for\s+/, '')
      .replace(/^app\s+/, '')
      .replace(/^the\s+/, '')
      .replace(/\s+on\s+play\s*store$/, '')
      .replace(/\s+on\s+playstore$/, '')
      .replace(/^[\s,.:;!?-]+|[\s,.:;!?-]+$/g, '')
      .trim();
    if (query && query !== 'kholo' && query !== 'open') {
      return { type: 'PLAY_STORE_SEARCH', query, rawInput: rawText };
    }
  }

  if (normalized === 'play store kholo' || normalized === 'playstore kholo' || normalized === 'open play store' || normalized === 'open playstore') {
    return { type: 'OPEN_APP', target: 'play store', rawInput: rawText };
  }

  // 4. YouTube Searches
  const ytHindiMatch = normalized.match(/^youtube\s+(?:par|pe|mein|me)\s+(.+?)(?:\s+(?:search\s+karo|chalao|dhoondo|dikhao|search))?$/) ||
                       normalized.match(/^(?:search\s+karo\s+)?youtube\s+(?:par|pe|mein|me)\s+(.+)$/);
  if (ytHindiMatch) {
    let query = ytHindiMatch[1].trim();
    query = query.replace(/^[\s,.:;!?-]+|[\s,.:;!?-]+$/g, '').trim();
    if (query && query !== 'kholo' && query !== 'open') {
      return { type: 'SEARCH_YOUTUBE', query, rawInput: rawText };
    }
  }

  const ytOnMatch = normalized.match(/^(?:search(?:\s+for)?|play)\s+(.*?)\s+on\s+youtube$/);
  if (ytOnMatch) {
    const query = ytOnMatch[1].replace(/^for\s+/, '').replace(/^[\s,.:;!?-]+|[\s,.:;!?-]+$/g, '').trim();
    if (query) {
      return { type: 'SEARCH_YOUTUBE', query, rawInput: rawText };
    }
  }

  const ytPrefix = normalized.match(/^(?:search\s+youtube(?:\s+for)?|youtube\s+search(?:\s+for)?|open\s+youtube\s+and\s+search(?:\s+for)?)\s+(.+)$/);
  if (ytPrefix) {
    const query = ytPrefix[1].replace(/^for\s+/, '').replace(/^[\s,.:;!?-]+|[\s,.:;!?-]+$/g, '').trim();
    if (query) {
      return { type: 'SEARCH_YOUTUBE', query, rawInput: rawText };
    }
  }

  // 5. Flashlight / Torch
  if (/\b(?:turn\s+on|enable|activate|switch\s+on|jalao|chalu\s+karo)\s+(?:the\s+)?(?:flashlight|torch)\b|\b(?:flashlight|torch)\s+(?:on|chalu|jalao|start)(?:\s+(?:karo|kar\s+do))?\b/.test(normalized)) {
    return { type: 'TOGGLE_FLASHLIGHT', state: true, rawInput: rawText };
  }
  if (/\b(?:turn\s+off|disable|deactivate|switch\s+off|bujhao|band\s+karo|band\s+kar\s+do)\s+(?:the\s+)?(?:flashlight|torch)\b|\b(?:flashlight|torch)\s+(?:off|band|bujhao)(?:\s+(?:karo|kar\s+do))?\b/.test(normalized)) {
    return { type: 'TOGGLE_FLASHLIGHT', state: false, rawInput: rawText };
  }
  if (/\b(?:toggle|switch)\s+(?:the\s+)?(?:flashlight|torch)\b|^(?:flashlight|torch)$/.test(normalized)) {
    return { type: 'TOGGLE_FLASHLIGHT', state: null, rawInput: rawText };
  }

  // 6. Volume
  if (/\b(?:volume|aawaz|awaaz|sound)\s+(?:kam|down|ghatao|dheemi)(?:\s+karo)?\b|\b(?:volume\s+down|lower\s+volume|decrease\s+volume)\b/.test(normalized)) {
    return { type: 'ADJUST_VOLUME', target: 'DOWN', rawInput: rawText };
  }
  if (/\b(?:volume|aawaz|awaaz|sound)\s+(?:badhao|up|tez|increase)(?:\s+karo)?\b|\b(?:volume\s+up|raise\s+volume|increase\s+volume)\b/.test(normalized)) {
    return { type: 'ADJUST_VOLUME', target: 'UP', rawInput: rawText };
  }
  if (/\b(?:mute|silent|chup\s+karo)\b/.test(normalized)) {
    return { type: 'ADJUST_VOLUME', target: 'MUTE', rawInput: rawText };
  }

  // 7. Contacts & Calling
  const findContact = normalized.match(/^(?:find|search(?:\s+for)?)\s+([a-z0-9\s._-]+?)\s+(?:in\s+(?:my\s+)?contacts|phonebook)$/);
  if (findContact) {
    return { type: 'CALL_CONTACT', target: findContact[1].replace(/^[\s,.:;!?-]+|[\s,.:;!?-]+$/g, '').trim(), rawInput: rawText };
  }

  const hindiCall = normalized.match(/^(.*?)\s+ko\s+(?:call|phone)\s+(?:karo|lagao|milao|kar\s+do)$/);
  if (hindiCall) {
    return { type: 'CALL_CONTACT', target: hindiCall[1].replace(/^[\s,.:;!?-]+|[\s,.:;!?-]+$/g, '').trim(), rawInput: rawText };
  }

  const englishCall = normalized.match(/^(?:call|dial|phone)\s+(?:to\s+)?([a-z0-9\s._-]+)$/);
  if (englishCall && !englishCall[1].includes('setting') && englishCall[1] !== 'me') {
    return { type: 'CALL_CONTACT', target: englishCall[1].replace(/^[\s,.:;!?-]+|[\s,.:;!?-]+$/g, '').trim(), rawInput: rawText };
  }

  // 8. General Settings
  if (/\b(?:open|launch|show|go to)\s+(?:the\s+)?settings$|^(?:settings?\s+(?:kholo|dikhao)|open\s+settings)$/.test(normalized)) {
    return { type: 'OPEN_SETTINGS', target: 'general', rawInput: rawText };
  }

  // 9. Time Query
  if (normalized.includes('kitne baje') || normalized.includes('time kya') || normalized.includes('what time') || normalized.includes('current time')) {
    return { type: 'SYSTEM_STATUS', target: 'time', rawInput: rawText };
  }

  // 10. History & Help
  if (/\b(?:show\s+(?:my\s+)?(?:recent\s+)?(?:commands|history)|view\s+history|history\s+dikhao|purani\s+commands?)\b|^history$/.test(normalized)) {
    return { type: 'SHOW_HISTORY', rawInput: rawText };
  }
  if (/\b(?:what\s+can\s+you\s+do|help\s+me|help|kya\s+kar\s+sakte\s+ho|madad\s+karo)\b|^help$/.test(normalized)) {
    return { type: 'SHOW_HELP', rawInput: rawText };
  }

  // 11. App Launch
  const hindiAppLaunch = normalized.match(/^(?:the\s+)?([a-z0-9\s._-]+)\s+(?:kholo|open\s+karo|chalu\s+karo)$/);
  if (hindiAppLaunch && !hindiAppLaunch[1].includes('setting')) {
    return { type: 'OPEN_APP', target: hindiAppLaunch[1].replace(/^[\s,.:;!?-]+|[\s,.:;!?-]+$/g, '').trim(), rawInput: rawText };
  }

  const appMatch = normalized.match(/^(?:open|launch|start|run|play)\s+(?:the\s+)?([a-z0-9\s._-]+)$/);
  if (appMatch && !appMatch[1].includes('setting')) {
    return { type: 'OPEN_APP', target: appMatch[1].replace(/^[\s,.:;!?-]+|[\s,.:;!?-]+$/g, '').trim(), rawInput: rawText };
  }

  // 12. Questions / AI
  if (/^(?:what|who|where|why|how|tell me|explain|calculate|kya|kaun|kahan|kaise)\b/.test(normalized)) {
    return { type: 'QUERY_AI', query: rawText, rawInput: rawText };
  }

  return { type: 'UNKNOWN', rawInput: rawText };
}

export const ALLOWED_ACTIONS = new Set([
  'OPEN_APP',
  'SEARCH_WEB',
  'SEARCH_YOUTUBE',
  'CALL_CONTACT',
  'SEND_WHATSAPP',
  'TOGGLE_FLASHLIGHT',
  'ADJUST_VOLUME',
  'OPEN_SETTINGS',
  'GET_BATTERY_STATUS',
  'CONVERSE',
  'SHOW_HISTORY',
  'SHOW_HELP'
]);

export function validateActionSafety(actionType: string): boolean {
  return ALLOWED_ACTIONS.has(actionType.trim().toUpperCase());
}

export function boundConversationHistory<T>(history: T[], maxTurns: number = 4): T[] {
  if (history.length <= maxTurns) return [...history];
  return history.slice(history.length - maxTurns);
}

/**
 * Pure logic State Machine model for unit testing state transitions and duplicate prevention.
 */
export type Phase =
  | 'STOPPED'
  | 'STARTING'
  | 'WAKE_WORD_LISTENING'
  | 'COMMAND_LISTENING'
  | 'PROCESSING'
  | 'SPEAKING'
  | 'ERROR';

export class PureStateMachine {
  currentPhase: Phase = 'STOPPED';
  activeSessionId: number = 0;
  executedSessionId: number = -1;
  errorRecoveryAttempts: number = 0;
  readonly maxRecoveryAttempts: number = 3;

  canTransitionTo(next: Phase): boolean {
    switch (this.currentPhase) {
      case 'STOPPED':
        return next === 'STARTING';
      case 'STARTING':
        return next === 'WAKE_WORD_LISTENING' || next === 'COMMAND_LISTENING' || next === 'ERROR' || next === 'STOPPED';
      case 'WAKE_WORD_LISTENING':
        return next === 'COMMAND_LISTENING' || next === 'PROCESSING' || next === 'SPEAKING' || next === 'STOPPED' || next === 'ERROR';
      case 'COMMAND_LISTENING':
        return next === 'PROCESSING' || next === 'WAKE_WORD_LISTENING' || next === 'STOPPED' || next === 'ERROR';
      case 'PROCESSING':
        return next === 'SPEAKING' || next === 'WAKE_WORD_LISTENING' || next === 'STOPPED' || next === 'ERROR';
      case 'SPEAKING':
        return next === 'WAKE_WORD_LISTENING' || next === 'COMMAND_LISTENING' || next === 'STOPPED' || next === 'ERROR';
      case 'ERROR':
        return next === 'WAKE_WORD_LISTENING' || next === 'STARTING' || next === 'STOPPED';
    }
  }

  transitionTo(next: Phase): boolean {
    if (!this.canTransitionTo(next)) return false;
    this.currentPhase = next;
    if (next === 'WAKE_WORD_LISTENING') {
      this.errorRecoveryAttempts = 0;
      this.executedSessionId = -1;
    }
    return true;
  }

  startNewSession(): number {
    this.activeSessionId++;
    this.transitionTo('STARTING');
    return this.activeSessionId;
  }

  stopSession() {
    this.currentPhase = 'STOPPED';
    this.executedSessionId = -1;
    this.errorRecoveryAttempts = 0;
  }

  beginCommandExecution(sessionId: number): boolean {
    if (sessionId !== this.activeSessionId) return false;
    if (this.executedSessionId === sessionId) return false;
    if (this.currentPhase !== 'PROCESSING') return false;

    this.executedSessionId = sessionId;
    return true;
  }

  handleRecognitionError(isFatalPermission: boolean): boolean {
    if (isFatalPermission) {
      this.currentPhase = 'ERROR';
      return false;
    }
    this.errorRecoveryAttempts++;
    if (this.errorRecoveryAttempts <= this.maxRecoveryAttempts) {
      this.currentPhase = 'WAKE_WORD_LISTENING';
      return true;
    } else {
      this.currentPhase = 'ERROR';
      return false;
    }
  }
}

/**
 * Pure logic Wake Word Debouncer model for unit testing.
 */
export class PureWakeWordDebouncer {
  private lastTriggerTime: number = -Infinity;
  constructor(private readonly cooldownMs: number = 1500) {}

  processHypothesis(hypothesis: string, now: number): boolean {
    const norm = hypothesis.trim().toLowerCase();
    const isWakeWord = norm === 'hey nova' || norm.startsWith('hey nova') || norm === 'ok nova' || norm === 'nova';
    if (!isWakeWord) return false;

    if (now - this.lastTriggerTime < this.cooldownMs) {
      return false; // rejected as duplicate in cooldown window
    }

    this.lastTriggerTime = now;
    return true;
  }
}
