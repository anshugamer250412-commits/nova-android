import test from 'node:test';
import assert from 'node:assert/strict';
import {
  validateGradleWrapperChecksum,
  validateProjectBundleRequirements,
  OFFICIAL_GRADLE_8_10_2_WRAPPER_SHA256
} from './verifier.ts';

test('validates correct official Gradle 8.10.2 wrapper sha256', () => {
  const result = validateGradleWrapperChecksum(
    '2db75c40782f5e8ba1fc278a5574bab070adccb2d21ca5a6e5ed840888448046'
  );
  assert.equal(result, true);
});

test('rejects tampered or incorrect wrapper checksum', () => {
  const result = validateGradleWrapperChecksum('badhash123');
  assert.equal(result, false);
});

test('validates project bundle required files exist', () => {
  const files = [
    'app/build.gradle.kts',
    'gradle/wrapper/gradle-wrapper.jar',
    '.github/workflows/build-apk.yml',
    'README.md'
  ];
  const validation = validateProjectBundleRequirements(files);
  assert.equal(validation.hasWrapperJar, true);
  assert.equal(validation.hasWorkflow, true);
  assert.equal(validation.hasReadme, true);
});
