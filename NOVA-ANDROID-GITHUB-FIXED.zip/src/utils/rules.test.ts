import test from 'node:test';
import assert from 'node:assert/strict';
import {
  parseVoiceCommand,
  validateActionSafety,
  boundConversationHistory,
  PureStateMachine,
  PureWakeWordDebouncer
} from './rules.ts';

test('CommandParser: parses English and Hindi flashlight commands', () => {
  const c1 = parseVoiceCommand('turn on flashlight');
  assert.equal(c1.type, 'TOGGLE_FLASHLIGHT');
  assert.equal(c1.state, true);

  const c2 = parseVoiceCommand('flashlight on karo');
  assert.equal(c2.type, 'TOGGLE_FLASHLIGHT');
  assert.equal(c2.state, true);

  const c3 = parseVoiceCommand('flashlight band kar do');
  assert.equal(c3.type, 'TOGGLE_FLASHLIGHT');
  assert.equal(c3.state, false);

  const c4 = parseVoiceCommand('torch bujhao');
  assert.equal(c4.type, 'TOGGLE_FLASHLIGHT');
  assert.equal(c4.state, false);
});

test('CommandParser: parses volume adjustments in English & Hindi', () => {
  const c1 = parseVoiceCommand('volume badhao');
  assert.equal(c1.type, 'ADJUST_VOLUME');
  assert.equal(c1.target, 'UP');

  const c2 = parseVoiceCommand('aawaz kam karo');
  assert.equal(c2.type, 'ADJUST_VOLUME');
  assert.equal(c2.target, 'DOWN');

  const c3 = parseVoiceCommand('volume down');
  assert.equal(c3.type, 'ADJUST_VOLUME');
  assert.equal(c3.target, 'DOWN');
});

test('CommandParser: parses contacts and calling in Hindi and English', () => {
  const c1 = parseVoiceCommand('Call Rahul.');
  assert.equal(c1.type, 'CALL_CONTACT');
  assert.equal(c1.target, 'rahul');

  const c2 = parseVoiceCommand('Rahul ko phone lagao.');
  assert.equal(c2.type, 'CALL_CONTACT');
  assert.equal(c2.target, 'rahul');

  const c3 = parseVoiceCommand('Call Mom');
  assert.equal(c3.type, 'CALL_CONTACT');
  assert.equal(c3.target, 'mom');

  const c4 = parseVoiceCommand('Find Amit in my contacts.');
  assert.equal(c4.type, 'CALL_CONTACT');
  assert.equal(c4.target, 'amit');

  const c5 = parseVoiceCommand('Rahul ko call karo.');
  assert.equal(c5.type, 'CALL_CONTACT');
  assert.equal(c5.target, 'rahul');
});

test('CommandParser: parses YouTube search variations', () => {
  const c1 = parseVoiceCommand('Hey NOVA, YouTube par Minecraft survival search karo.');
  assert.equal(c1.type, 'SEARCH_YOUTUBE');
  assert.equal(c1.query, 'minecraft survival');

  const c2 = parseVoiceCommand('YouTube pe latest gaming videos search karo.');
  assert.equal(c2.type, 'SEARCH_YOUTUBE');
  assert.equal(c2.query, 'latest gaming videos');

  const c3 = parseVoiceCommand('Search YouTube for Minecraft shaders.');
  assert.equal(c3.type, 'SEARCH_YOUTUBE');
  assert.equal(c3.query, 'minecraft shaders');

  const c4 = parseVoiceCommand('YouTube pe Free Fire search karo.');
  assert.equal(c4.type, 'SEARCH_YOUTUBE');
  assert.equal(c4.query, 'free fire');
});

test('CommandParser: parses Play Store searches and app opening', () => {
  const c1 = parseVoiceCommand('Play Store par Minecraft search karo.');
  assert.equal(c1.type, 'PLAY_STORE_SEARCH');
  assert.equal(c1.query, 'minecraft');

  const c2 = parseVoiceCommand('Find WhatsApp on Play Store.');
  assert.equal(c2.type, 'PLAY_STORE_SEARCH');
  assert.equal(c2.query, 'whatsapp');

  const c3 = parseVoiceCommand('Play Store mein photo editor search karo.');
  assert.equal(c3.type, 'PLAY_STORE_SEARCH');
  assert.equal(c3.query, 'photo editor');

  const c4 = parseVoiceCommand('download Spotify');
  assert.equal(c4.type, 'PLAY_STORE_SEARCH');
  assert.equal(c4.query, 'spotify');

  const c5 = parseVoiceCommand('Play Store kholo.');
  assert.equal(c5.type, 'OPEN_APP');
  assert.equal(c5.target, 'play store');
});

test('CommandParser: parses Wi-Fi and Bluetooth settings requests', () => {
  const c1 = parseVoiceCommand('Wi-Fi settings kholo.');
  assert.equal(c1.type, 'OPEN_SETTINGS');
  assert.equal(c1.target, 'wifi');

  const c2 = parseVoiceCommand('Bluetooth settings kholo.');
  assert.equal(c2.type, 'OPEN_SETTINGS');
  assert.equal(c2.target, 'bluetooth');

  const c3 = parseVoiceCommand('Open Bluetooth settings.');
  assert.equal(c3.type, 'OPEN_SETTINGS');
  assert.equal(c3.target, 'bluetooth');

  const c4 = parseVoiceCommand('turn on wifi');
  assert.equal(c4.type, 'OPEN_SETTINGS');
  assert.equal(c4.target, 'wifi');
});

test('CommandParser: parses time, history, help, questions and unknown', () => {
  assert.equal(parseVoiceCommand('Abhi kitne baje hain?').type, 'SYSTEM_STATUS');
  assert.equal(parseVoiceCommand('Open settings.').type, 'OPEN_SETTINGS');
  assert.equal(parseVoiceCommand('show my recent commands').type, 'SHOW_HISTORY');
  assert.equal(parseVoiceCommand('history dikhao').type, 'SHOW_HISTORY');
  assert.equal(parseVoiceCommand('what can you do').type, 'SHOW_HELP');
  assert.equal(parseVoiceCommand('What is the speed of light?').type, 'QUERY_AI');
  assert.equal(parseVoiceCommand('xyz abc meaningless babble').type, 'UNKNOWN');
});

test('Security allowlist: allows approved phone actions and blocks unauthorized actions', () => {
  for (const action of ['OPEN_APP', 'SEARCH_WEB', 'SEARCH_YOUTUBE', 'CALL_CONTACT', 'TOGGLE_FLASHLIGHT', 'CONVERSE', 'OPEN_SETTINGS']) {
    assert.equal(validateActionSafety(action), true);
  }
  assert.equal(validateActionSafety('RUN_SHELL'), false);
  assert.equal(validateActionSafety('EXECUTE_SCRIPT'), false);
  assert.equal(validateActionSafety('DELETE_FILES'), false);
  assert.equal(validateActionSafety('INSTALL_MALWARE'), false);
});

test('Conversation Context: limits history window to bounded size', () => {
  const turns = [
    { u: '1', a: '1' },
    { u: '2', a: '2' },
    { u: '3', a: '3' },
    { u: '4', a: '4' },
    { u: '5', a: '5' },
    { u: '6', a: '6' }
  ];
  const bounded = boundConversationHistory(turns, 4);
  assert.equal(bounded.length, 4);
  assert.equal(bounded[0].u, '3');
  assert.equal(bounded[3].u, '6');
});

test('State Machine: validates lifecycle transitions and rejects illegal jumps', () => {
  const sm = new PureStateMachine();
  assert.equal(sm.currentPhase, 'STOPPED');

  // Illegal transition: STOPPED cannot jump to SPEAKING
  assert.equal(sm.transitionTo('SPEAKING'), false);
  assert.equal(sm.currentPhase, 'STOPPED');

  // Valid flow
  assert.equal(sm.transitionTo('STARTING'), true);
  assert.equal(sm.transitionTo('WAKE_WORD_LISTENING'), true);
  assert.equal(sm.transitionTo('COMMAND_LISTENING'), true);
  assert.equal(sm.transitionTo('PROCESSING'), true);
  assert.equal(sm.transitionTo('SPEAKING'), true);
  assert.equal(sm.transitionTo('WAKE_WORD_LISTENING'), true);
});

test('State Machine: prevents duplicate command execution on same session', () => {
  const sm = new PureStateMachine();
  const sessionId = sm.startNewSession();
  sm.transitionTo('WAKE_WORD_LISTENING');
  sm.transitionTo('COMMAND_LISTENING');
  sm.transitionTo('PROCESSING');

  assert.equal(sm.beginCommandExecution(sessionId), true);
  // Duplicate callback must be rejected
  assert.equal(sm.beginCommandExecution(sessionId), false);
});

test('Wake Word Debouncer: rejects duplicate wake events within cooldown window', () => {
  const debouncer = new PureWakeWordDebouncer(1500);

  // Unrelated speech
  assert.equal(debouncer.processHypothesis('good morning everyone', 1000), false);

  // First wake-word
  assert.equal(debouncer.processHypothesis('Hey NOVA', 1000), true);

  // Duplicate utterance within cooldown (e.g. 500ms later)
  assert.equal(debouncer.processHypothesis('Hey NOVA', 1500), false);

  // New utterance after cooldown (1600ms later)
  assert.equal(debouncer.processHypothesis('Hey NOVA', 2600), true);
});
