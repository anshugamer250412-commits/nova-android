# NOVA Phase 1 - "Hey NOVA" wake word: implementation + honest verification status

**Status: implemented, NOT built, NOT tested.** The authoring sandbox had no network, no Android SDK, no Gradle
distribution, no Kotlin compiler and no Vosk model. Checks A-H below were therefore **not run**. Nothing here
should be read as "working" until you run the commands in section 4.

## 1. Files changed (all under android_nova/ unless noted)
Modified: `app/build.gradle.kts`, `gradle/libs.versions.toml` (+ identical root copy `gradle/libs.versions.toml`),
`.gitignore`, `README.md`, `NovaApplication.kt`, `service/NovaVoiceService.kt`, `wakeword/WakeWordEngine.kt` (rewritten),
`test/.../WakeWordEngineTest.kt` (rewritten).
Added: `wakeword/WakePhraseMatcher.kt`, `wakeword/WakeWordModelStore.kt`, `wakeword/WakeWordListener.kt`,
`test/.../WakePhraseMatcherTest.kt`, `test/.../WakeWordModelStoreTest.kt`,
`androidTest/.../WakeWordInstrumentedTest.kt`, `androidTest/assets/wake_test/**` (12 synthetic clips + README).
Deleted: `wakeword/WakeWordService.kt` (unregistered in the manifest, contained a placeholder capture loop and a
second AudioRecord that would compete for the mic).
Byte-identical (verified with `cmp`): CommandParser, NovaCommand, FlashlightController, AppLauncher, ContactCaller,
NovaTTS, HomeScreen, SettingsScreen, MainActivity, CommandParserTest.

## 2. Model and integration
- Engine: Vosk, `com.alphacephei:vosk-android:0.3.47` + `net.java.dev.jna:jna:5.13.0@aar` (coordinates from memory, unresolved here).
- Model: `vosk-model-small-en-us-0.15` (Apache 2.0, ~40 MB), https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip
- Why this model: small Vosk models carry a dynamic graph (HCLr.fst/Gr.fst), required for `Recognizer(model, rate, grammar)`.
- NOT bundled in this ZIP (cannot download here). `fetchVoskModel` Gradle task downloads it at build time into
  `build/generated/voskModel/model-en-us` (assets); skipped if `app/src/main/assets/model-en-us/` already holds it.
  The build log prints the zip's SHA-256; pin it with `-PvoskModelSha256=...`.
- Audio: 16 000 Hz, mono, PCM 16-bit (`AudioRecord`, source VOICE_RECOGNITION), 100 ms frames.
- Detection: grammar `["hey nova","[unk]"]`; match = words "hey","nova" consecutive in Vosk's output (partial result
  triggers a flush to get word confidences; final result at endpoint). Confidence floor 0.5 (UNCALIBRATED).
- No RMS/energy detection anywhere (old `VoiceActivityOnsetSpotter`, `TestablePhraseDecoder`, reflection decoder removed).
- Load-time check: model must contain `am/final.mdl, conf/mfcc.conf, graph/HCLr.fst, graph/Gr.fst, graph/words.txt`
  and `graph/words.txt` must list "hey" and "nova", otherwise load fails with an explicit error.

## 3. Behaviour of the flow (by code reading only)
service start -> model loads on a background thread -> `WakeWordListener` owns the mic (`WAKE_WORD_LISTENING`)
-> genuine match -> AudioRecord stopped+released on the capture thread BEFORE the callback -> main thread:
SPEAKING "Yes?" (existing TTS) -> `startCommandListening()` (SpeechRecognizer, `COMMAND_LISTENING`)
-> command executes -> existing TTS -> `startWakeWordListening()` resumes. Push-to-talk and Stop always call
`stopWakeWordCapture()` first (join, bounded 2 s). Stale callbacks are discarded with a capture-id token.

Changes outside pure wake detection (revert if you disagree):
1. `onResults` now also handles phase PROCESSING. Previously `onEndOfSpeech` moved the phase to PROCESSING first and
   the result fell into the `else` branch, so the spoken command was dropped.
2. Foreground-service type MICROPHONE is now passed from API 30 (was API 34); NONE blocks background mic on 11-13 (per docs).
3. 4 s watchdog after "Yes?" because `NovaTTS.onError` never invokes the completion callback (NovaTTS itself untouched).
4. `NovaApplication` no longer loads the model on the main thread; listening-mode checks use `WakeWordModelStore.isBundled`.
5. Behaviour change: "Hey NOVA open YouTube" in one breath no longer carries the command; it is now wake -> "Yes?" -> command.

## 4. Verification checklist - what ran and what did not
| Check | Status |
|---|---|
| A. real model loads | NOT RUN (no model, no native lib). Run `connectedDebugAndroidTest` -> `realModelLoadsAndVocabularyContainsWakeWords` |
| B. detects "Hey Nova" | NOT RUN. `detectsHeyNovaClips` (4 synthetic TTS clips; add real recordings) |
| C. speech/noise don't activate | NOT RUN. `ignoresUnrelatedSpeechClips`, `ignoresLoudWhiteNoise`, `ignoresHumAndClicks`, `ignoresSilence` |
| D. wake -> COMMAND_LISTENING | NOT RUN on a device. Only the state-machine transitions pre-exist in `AssistantStateMachineTest` (not re-run) |
| E. mic released/transferred | NOT RUN. `listenerReleasesMicrophoneAndCaptureThreadOnStop` |
| F. `./gradlew assembleDebug` | NOT RUN |
| G. unit tests | NOT RUN (`./gradlew testDebugUnitTest`) |
| H. fix compile errors | NOT POSSIBLE - nothing was compiled |
| Physical phone test | NOT DONE |

What WAS actually executed here: bracket-balance scan of every changed Kotlin/Gradle file (all balanced - a crude
syntax screen, not compilation); `cmp` of protected files (identical); `ffprobe` of the 12 fixture clips
(all `pcm_s16le, 16000 Hz, 1 ch`).

## 5. Known unverified assumptions / risks
- Maven coordinates/versions and the model URL/zip layout are from memory.
- The Gradle DSL (custom task + `androidComponents.onVariants`) and all Kotlin were never compiled.
- Vosk grammar mode can accept similar-sounding speech; word confidences in grammar mode may sit near 1.0, so the 0.5
  floor may filter nothing. No false-accept rate has been measured. "nova" being in the model vocabulary is checked only at runtime.
- Synthetic (flite) clips may fail to match for accent reasons; that would not necessarily indicate a code bug.
- Continuous decoding costs CPU/battery; not measured. OEM battery killers / Doze not tested.
